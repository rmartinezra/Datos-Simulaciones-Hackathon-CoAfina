from __future__ import annotations

import argparse
import json
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from campaign_common import PROJECT_ROOT, load_config, sha256_file


@dataclass
class Check:
    name: str
    status: str
    detail: str


def read_partitioned(root: Path) -> pd.DataFrame:
    files = sorted(root.glob("**/*.parquet"))
    if not files:
        return pd.DataFrame()
    frames = [pd.read_parquet(path) for path in files]
    populated = [frame for frame in frames if len(frame)]
    return pd.concat(populated, ignore_index=True) if populated else frames[0]


def add_check(checks: list[Check], name: str, condition: bool, detail: str) -> None:
    checks.append(Check(name, "PASS" if condition else "FAIL", detail))


def add_warning(checks: list[Check], name: str, condition: bool, detail: str) -> None:
    checks.append(Check(name, "PASS" if condition else "WARN", detail))


def finite(frame: pd.DataFrame, columns: list[str]) -> bool:
    return all(np.isfinite(frame[column].to_numpy(dtype=float)).all() for column in columns)


def validate(stage: str, table_root: Path) -> dict[str, Any]:
    config = load_config()
    checks: list[Check] = []
    required = [
        table_root / "conditions.parquet",
        table_root / "runs.parquet",
        table_root / "showers.parquet",
        table_root / "dataset_metadata.json",
    ]
    add_check(checks, "archivos_tabulares", all(path.is_file() for path in required),
              f"{sum(path.is_file() for path in required)}/{len(required)} archivos principales")
    if any(not path.is_file() for path in required):
        return finish_report(stage, table_root, checks, {})

    metadata = json.loads((table_root / "dataset_metadata.json").read_text(encoding="utf-8"))
    conditions = pd.read_parquet(table_root / "conditions.parquet")
    runs = pd.read_parquet(table_root / "runs.parquet")
    showers = pd.read_parquet(table_root / "showers.parquet")
    particles = read_partitioned(table_root / "particles")
    long_particles = read_partitioned(table_root / "longitudinal_particles")
    long_deposit = read_partitioned(table_root / "longitudinal_energy_deposit")

    add_check(checks, "etapa_metadatos", metadata.get("stage") == stage,
              f"metadata.stage={metadata.get('stage')!r}, esperado={stage!r}")
    expected_conditions = {item["condition_id"] for item in config["conditions"]}
    found_conditions = set(conditions["condition_id"])
    add_check(checks, "matriz_condiciones", found_conditions == expected_conditions,
              f"{len(found_conditions)}/{len(expected_conditions)} condiciones")
    add_check(checks, "corridas_completas", bool(len(runs)) and runs["status"].eq("complete").all(),
              f"completas={int(runs['status'].eq('complete').sum())}, total={len(runs)}")
    add_check(checks, "ids_corrida_unicos", runs["run_id"].is_unique,
              f"unicos={runs['run_id'].nunique()}, filas={len(runs)}")
    add_check(checks, "ids_cascada_unicos", showers["shower_id"].is_unique,
              f"unicos={showers['shower_id'].nunique()}, filas={len(showers)}")

    condition_counts = showers.groupby("condition_id")["shower_id"].size().reindex(sorted(expected_conditions), fill_value=0)
    if stage == "matrix":
        expected_per_condition = 1
    elif stage == "pilot":
        expected_per_condition = 5
    elif stage == "production":
        plan_path = PROJECT_ROOT / "manifests/production_plan.json"
        expected_per_condition = int(json.loads(plan_path.read_text(encoding="utf-8"))["planned_events_per_condition"])
    else:
        expected_per_condition = 2
    if stage == "reproducibility":
        uniform = bool((condition_counts > 0).sum() == 1 and condition_counts.max() == expected_per_condition)
    else:
        uniform = bool(
            condition_counts.nunique() == 1
            and len(condition_counts) == len(expected_conditions)
            and condition_counts.eq(expected_per_condition).all()
        )
    add_check(checks, "cascadas_por_condicion_uniformes", uniform,
              f"esperado={expected_per_condition}; "
              + json.dumps({key: int(value) for key, value in condition_counts.items()}, sort_keys=True))
    add_check(checks, "conteo_metadatos",
              int(metadata.get("showers_complete", -1)) == len(showers)
              and int(metadata.get("particle_rows", -1)) == len(particles),
              f"cascadas={len(showers)}, particulas={len(particles)}")

    joined = showers.merge(
        conditions[["condition_id", "primary_code", "energy_total_GeV", "zenith_deg", "azimuth_deg"]],
        on="condition_id", how="left", validate="many_to_one",
    )
    primary_ok = (
        joined["primary_code_header"].eq(joined["primary_code"])
        & np.isclose(joined["primary_energy_total_GeV_header"], joined["energy_total_GeV"], rtol=2e-6, atol=1e-5)
        & np.isclose(joined["primary_zenith_deg_header"], joined["zenith_deg"], atol=2e-4)
        & np.isclose(joined["primary_azimuth_deg_header"], joined["azimuth_deg"], atol=2e-4)
    ).all()
    add_check(checks, "entrada_vs_cabecera_primaria", bool(primary_ok),
              "especie, energia total, cenit y azimut")
    primary_p = np.sqrt(
        joined["primary_px_GeV_c_header"] ** 2
        + joined["primary_py_GeV_c_header"] ** 2
        + joined["primary_pz_down_GeV_c_header"] ** 2
    )
    primary_theta = np.degrees(np.arccos(np.clip(joined["primary_pz_down_GeV_c_header"] / primary_p, -1, 1)))
    primary_phi = np.degrees(np.arctan2(joined["primary_py_GeV_c_header"], joined["primary_px_GeV_c_header"]))
    primary_mass = np.where(joined["primary_code_header"].eq(14), 0.93827200, 0.0)
    primary_energy_from_p = np.sqrt(primary_p ** 2 + primary_mass ** 2)
    add_check(checks, "momento_primario",
              bool(np.allclose(primary_theta, joined["primary_zenith_deg_header"], atol=2e-4)
                   and np.allclose(primary_phi, joined["primary_azimuth_deg_header"], atol=2e-4)
                   and np.allclose(primary_energy_from_p, joined["primary_energy_total_GeV_header"], rtol=2e-6, atol=1e-5)),
              "componentes norte/oeste/abajo reproducen direccion y energia total")
    obs_expected = float(config["physics"]["observation_level_m_asl"])
    add_check(checks, "nivel_observacion",
              bool(np.isclose(showers["observation_level_m_asl"], obs_expected, atol=1e-4).all()),
              f"esperado={obs_expected} m s.n.m.")
    shower_required_numeric = [
        "primary_energy_total_GeV_header", "primary_zenith_deg_header", "primary_azimuth_deg_header",
        "primary_px_GeV_c_header", "primary_py_GeV_c_header", "primary_pz_down_GeV_c_header",
        "first_interaction_height_raw_cm", "first_interaction_height_m_asl",
        "observation_level_m_asl", "longitudinal_fit_chi_square",
    ]
    add_check(checks, "cabeceras_cascada_finitas", finite(showers, shower_required_numeric),
              "campos fisicos obligatorios de EVTH/EVTE")
    add_check(checks, "altura_primera_interaccion",
              bool(showers["first_interaction_height_m_asl"].gt(showers["observation_level_m_asl"]).all()
                   and np.allclose(
                       showers["first_interaction_height_m_asl"],
                       showers["first_interaction_height_raw_cm"].abs() / 100.0,
                       atol=1e-9,
                   )),
              "magnitud de EVTH(7), por encima del nivel de observacion; signo conservado como bandera")
    add_check(checks, "cabeceras_corrida",
              bool(runs["run_header_run_number"].eq(runs["run_number"]).all()
                   and runs["run_header_n_showers"].eq(runs["n_showers"]).all()
                   and runs["run_end_n_showers"].eq(runs["n_showers"]).all()
                   and runs["events_read"].eq(runs["n_showers"]).all()
                   and runs["profiles_read"].eq(runs["n_showers"]).all()),
              "RUNH/RUNE/eventos/perfiles coinciden con la tarjeta")
    add_check(checks, "version_cabecera",
              bool(np.isclose(runs["run_header_version"], float(config["corsika"]["version"]), atol=5e-5).all()),
              f"RUNH declara CORSIKA {config['corsika']['version']}")
    add_check(checks, "formato_binario",
              bool(runs["layout_record_payload_bytes"].eq(22_932).all()
                   and runs["layout_fortran_record_marker_bytes"].isin([4, 8]).all()
                   and ~runs["layout_thinning_format"].astype(bool).any()),
              "registros sin thinning de 7 palabras; marcadores Fortran verificados")
    tags_ok = True
    for row in runs.itertuples(index=False):
        tags = json.loads(row.layout_tags)
        tags_ok = tags_ok and tags.get("RUNH", 0) == 1 and tags.get("RUNE", 0) == 1
        tags_ok = tags_ok and tags.get("EVTH", 0) == row.n_showers and tags.get("EVTE", 0) == row.n_showers
    add_check(checks, "bloques_binarios", bool(tags_ok),
              "RUNH/RUNE unicos y un par EVTH/EVTE por evento")

    shower_ids = set(showers["shower_id"])
    add_check(checks, "fk_particulas", set(particles.get("shower_id", [])) <= shower_ids,
              f"filas={len(particles)}")
    add_check(checks, "fk_perfiles",
              set(long_particles.get("shower_id", [])) <= shower_ids
              and set(long_deposit.get("shower_id", [])) <= shower_ids,
              f"poblaciones={len(long_particles)}, depositos={len(long_deposit)}")

    if len(particles):
        key_unique = ~particles.duplicated(["shower_id", "particle_row_id"]).any()
        per_shower = particles.groupby("shower_id")["particle_row_id"].agg(["size", "min", "max", "nunique"])
        sequential = bool(((per_shower["min"] == 0)
                           & (per_shower["max"] == per_shower["size"] - 1)
                           & (per_shower["nunique"] == per_shower["size"])).all())
        add_check(checks, "ids_fila_particula", bool(key_unique and sequential),
                  "unicos y consecutivos dentro de cada cascada; no son track_id")
        observed_counts = particles.groupby("shower_id").size()
    else:
        add_check(checks, "ids_fila_particula", True, "sin filas de particulas")
        observed_counts = pd.Series(dtype=int)
    expected_counts = showers.set_index("shower_id")["n_particle_records"].astype(int)
    aligned_counts = observed_counts.reindex(expected_counts.index, fill_value=0).astype(int)
    add_check(checks, "conteos_por_cascada", aligned_counts.equals(expected_counts),
              f"total_tabla={int(aligned_counts.sum())}, total_resumen={int(expected_counts.sum())}")
    group_sum = showers[["n_electromagnetic", "n_muon", "n_hadron", "n_nucleus", "n_unknown"]].sum(axis=1)
    add_check(checks, "conteos_por_grupo", bool(group_sum.eq(showers["n_particle_records"]).all()),
              "grupos suman los registros de cada cascada")
    add_check(checks, "conteo_evte", bool(showers["event_end_n_particles_written"].eq(showers["n_particle_records"]).all()),
              "EVTE coincide con filas leidas")
    nonempty_showers = showers["n_particle_records"].gt(0)
    spatial_time_summary = [
        "radial_arc_max_m", "distance_to_axis_max_m", "time_corsika_min_ns", "time_corsika_max_ns", "time_span_ns"
    ]
    summaries_ok = (
        finite(showers.loc[nonempty_showers], spatial_time_summary)
        and showers.loc[~nonempty_showers, spatial_time_summary].isna().all().all()
    )
    add_check(checks, "resumenes_vacios_y_no_vacios", bool(summaries_ok),
              "resumenes finitos si hay registros y nulos si no los hay")

    original_numeric = ["px_GeV_c", "py_GeV_c", "pz_down_GeV_c", "x_output_cm", "y_output_cm", "time_corsika_ns"]
    add_check(checks, "valores_originales_finitos", finite(particles, original_numeric) if len(particles) else True,
              ", ".join(original_numeric))
    add_check(checks, "peso_sin_thinning",
              bool((particles["statistical_weight"] == 1.0).all()
                   and particles["statistical_weight_source"].eq("implicit_unthinned").all()) if len(particles) else True,
              "peso implicito=1")
    add_check(checks, "indice_nivel_observacion",
              bool(particles["observation_level_index"].eq(1).all()) if len(particles) else True,
              "unico nivel, indice CORSIKA 1")

    known = particles["mass_GeV_c2"].notna() if len(particles) else pd.Series(dtype=bool)
    if known.any():
        p2 = particles.loc[known, "momentum_GeV_c"].to_numpy() ** 2
        m2 = particles.loc[known, "mass_GeV_c2"].to_numpy() ** 2
        e = particles.loc[known, "energy_total_GeV"].to_numpy()
        relation_ok = np.allclose(e * e, p2 + m2, rtol=2e-12, atol=2e-12)
    else:
        relation_ok = True
    add_check(checks, "relacion_energia_momento", bool(relation_ok),
              f"conversiones con masa verificada={int(known.sum())}")
    unknown = particles["species"].isna() if len(particles) else pd.Series(dtype=bool)
    add_warning(checks, "codigos_particula_reconocidos", not bool(unknown.any()),
                f"desconocidos={int(unknown.sum())}; se mantienen nulos, nunca inferidos")
    if len(particles):
        radial_arc_expected = np.hypot(particles["x_output_cm"], particles["y_output_cm"]) / 100.0
        radial_chord_expected = np.hypot(particles["x_cartesian_m"], particles["y_cartesian_m"])
        earth_radius_m = 6_371_315.0
        surface_radius = np.sqrt(
            particles["x_cartesian_m"] ** 2
            + particles["y_cartesian_m"] ** 2
            + (earth_radius_m + particles["z_cartesian_local_m"]) ** 2
        )
        coordinate_ok = (
            np.allclose(particles["radial_arc_m"], radial_arc_expected, rtol=2e-12, atol=2e-9)
            and np.allclose(particles["radial_chord_m"], radial_chord_expected, rtol=2e-12, atol=2e-9)
            and np.allclose(surface_radius, earth_radius_m + obs_expected, rtol=2e-12, atol=2e-6)
            and particles["distance_to_shower_axis_m"].ge(0).all()
        )
        add_check(checks, "coordenadas_derivadas", bool(coordinate_ok),
                  "arco, cuerda, superficie esferica y distancia al eje coherentes")
        direction_norm = np.sqrt(
            particles["direction_north"] ** 2
            + particles["direction_west"] ** 2
            + particles["direction_down"] ** 2
        )
        add_check(checks, "direcciones_unitarias", bool(np.allclose(direction_norm, 1.0, atol=2e-12)),
                  "componentes derivadas de momento")
        rel_min = particles.groupby("shower_id")["time_relative_first_particle_ns"].min()
        add_check(checks, "tiempo_relativo", bool(np.allclose(rel_min, 0.0, atol=1e-6)),
                  "se conserva time_corsika_ns y la columna derivada inicia en cero")
    else:
        add_check(checks, "coordenadas_derivadas", True, "sin filas")
        add_check(checks, "direcciones_unitarias", True, "sin filas")
        add_check(checks, "tiempo_relativo", True, "sin filas")

    profiled = set(long_particles["shower_id"]) & set(long_deposit["shower_id"])
    add_check(checks, "perfil_por_cascada", profiled == shower_ids,
              f"con ambos perfiles={len(profiled)}, cascadas={len(shower_ids)}")
    depth_ok = True
    for frame in (long_particles, long_deposit):
        if len(frame):
            depth_ok = depth_ok and finite(frame, ["depth_vertical_g_cm2"])
            depth_ok = depth_ok and bool(frame.groupby("shower_id")["depth_vertical_g_cm2"].apply(
                lambda values: values.is_monotonic_increasing and not values.duplicated().any()
            ).all())
    add_check(checks, "profundidad_longitudinal", bool(depth_ok),
              "profundidad vertical finita, creciente y sin duplicados por cascada")
    long_particle_values = [
        "gammas", "positrons", "electrons", "mu_plus", "mu_minus", "hadrons", "charged", "nuclei", "cherenkov"
    ]
    long_deposit_values = [
        "gamma_cut_GeV", "em_ionization_GeV", "em_cut_GeV", "muon_ionization_GeV",
        "muon_cut_GeV", "hadron_ionization_GeV", "hadron_cut_GeV", "neutrino_GeV", "sum_deposit_GeV",
    ]
    profile_values_ok = (
        finite(long_particles, long_particle_values)
        and finite(long_deposit, long_deposit_values)
        and (long_particles[long_particle_values].to_numpy(dtype=float) >= 0).all()
        and (long_deposit[long_deposit_values].to_numpy(dtype=float) >= 0).all()
    )
    add_check(checks, "valores_perfiles", bool(profile_values_ok),
              "poblaciones y depositos finitos y no negativos")

    if stage != "reproducibility":
        seeds_per_run = showers.groupby("run_id")[["seed_sequence_1", "seed_sequence_2"]].nunique()
        one_pair_per_run = bool(seeds_per_run.eq(1).all().all())
        run_seed_pairs = showers.groupby("run_id")[["seed_sequence_1", "seed_sequence_2"]].first()
        requested_pairs = runs[["run_id", "seed_sequence_1_requested", "seed_sequence_2_requested"]]
        unique_between_runs = not requested_pairs.duplicated(
            ["seed_sequence_1_requested", "seed_sequence_2_requested"]
        ).any()
        seed_join = runs[["run_id", "seed_sequence_1_requested", "seed_sequence_2_requested"]].merge(
            run_seed_pairs.reset_index(), on="run_id", how="left", validate="one_to_one"
        )
        expected_header_seed_1 = seed_join["seed_sequence_1_requested"].astype(np.float32).round().astype(np.int64)
        expected_header_seed_2 = seed_join["seed_sequence_2_requested"].astype(np.float32).round().astype(np.int64)
        requested_matches_header = bool(
            seed_join["seed_sequence_1"].eq(expected_header_seed_1).all()
            and seed_join["seed_sequence_2"].eq(expected_header_seed_2).all()
        )
        add_check(checks, "semillas_por_corrida", bool(one_pair_per_run and unique_between_runs),
                  f"pares exactos distintos entre trabajos={requested_pairs.drop_duplicates(['seed_sequence_1_requested','seed_sequence_2_requested']).shape[0]}/{len(requested_pairs)}; "
                  "EVTH repite las semillas iniciales dentro de la corrida")
        add_check(checks, "semillas_tarjeta_vs_evth", requested_matches_header,
                  "EVTH coincide con la representacion float32 de las semillas enteras exactas de la tarjeta")

    hash_ok = True
    checked_hashes = 0
    for row in runs.itertuples(index=False):
        if row.status != "complete":
            continue
        for path_value, expected in ((row.raw_path, row.raw_sha256), (row.longitudinal_path, row.longitudinal_sha256)):
            path = PROJECT_ROOT / path_value
            hash_ok = hash_ok and path.is_file() and sha256_file(path) == expected
            checked_hashes += 1
    add_check(checks, "integridad_sha256_fuentes", bool(hash_ok), f"archivos comprobados={checked_hashes}")

    metrics = {
        "conditions": len(conditions),
        "runs": len(runs),
        "showers": len(showers),
        "showers_without_ground_particles": int(showers["n_particle_records"].eq(0).sum()),
        "particle_rows": len(particles),
        "longitudinal_particle_rows": len(long_particles),
        "longitudinal_deposit_rows": len(long_deposit),
        "unknown_particle_rows": int(unknown.sum()),
    }
    return finish_report(stage, table_root, checks, metrics)


def finish_report(stage: str, table_root: Path, checks: list[Check], metrics: dict[str, Any]) -> dict[str, Any]:
    report = {
        "stage": stage,
        "validated_utc": datetime.now(timezone.utc).isoformat(),
        "table_root": str(table_root),
        "status": "FAIL" if any(item.status == "FAIL" for item in checks) else "PASS",
        "checks_passed": sum(item.status == "PASS" for item in checks),
        "checks_warned": sum(item.status == "WARN" for item in checks),
        "checks_failed": sum(item.status == "FAIL" for item in checks),
        "metrics": metrics,
        "checks": [asdict(item) for item in checks],
    }
    report_dir = PROJECT_ROOT / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    json_path = report_dir / f"validation_{stage}.json"
    md_path = report_dir / f"validation_{stage}.md"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    lines = [
        f"# Validacion de {stage}", "", f"Estado: **{report['status']}**", "",
        "| Comprobacion | Estado | Detalle |", "|---|---:|---|",
    ]
    for item in checks:
        detail = item.detail.replace("|", "\\|").replace("\n", " ")
        lines.append(f"| `{item.name}` | {item.status} | {detail} |")
    lines += ["", "## Metricas", "", "```json", json.dumps(metrics, indent=2, ensure_ascii=False), "```", ""]
    md_path.write_text("\n".join(lines), encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Valida las tablas independientes de CORSIKA 7")
    parser.add_argument("--stage", default="production", choices=["matrix", "pilot", "production", "reproducibility"])
    parser.add_argument("--input", type=Path)
    args = parser.parse_args()
    root = args.input or (PROJECT_ROOT / ("data/full" if args.stage == "production" else f"_work/{args.stage}_tables"))
    report = validate(args.stage, root)
    print(json.dumps({key: report[key] for key in ["stage", "status", "checks_passed", "checks_warned", "checks_failed", "metrics"]}, indent=2, ensure_ascii=False))
    if report["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()

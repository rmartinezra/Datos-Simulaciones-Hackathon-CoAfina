from __future__ import annotations

import json
from datetime import datetime, timezone

from campaign_common import PROJECT_ROOT, sha256_file


def main() -> None:
    manifest_path = PROJECT_ROOT / "manifests/reproducibility_runs.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    runs = sorted(manifest["runs"], key=lambda item: item["replicate"])
    files_ok = True
    for run in runs:
        for path_key, hash_key in (("raw_path", "raw_sha256"), ("longitudinal_path", "longitudinal_sha256"),
                                   ("card_path", "card_sha256")):
            path = PROJECT_ROOT / run[path_key]
            files_ok = files_ok and path.is_file() and sha256_file(path) == run[hash_key]
    same_card = len(runs) == 2 and runs[0]["card_sha256"] == runs[1]["card_sha256"]
    same_particles = len(runs) == 2 and runs[0]["raw_sha256"] == runs[1]["raw_sha256"]
    same_longitudinal = len(runs) == 2 and runs[0]["longitudinal_sha256"] == runs[1]["longitudinal_sha256"]
    report = {
        "checked_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if files_ok and same_card and same_particles and same_longitudinal else "FAIL",
        "condition_id": runs[0]["condition_id"] if runs else None,
        "run_number": runs[0]["run_number"] if runs else None,
        "replicates": [run["replicate"] for run in runs],
        "same_card_sha256": same_card,
        "same_particle_output_sha256": same_particles,
        "same_longitudinal_output_sha256": same_longitudinal,
        "particle_sha256": runs[0]["raw_sha256"] if same_particles else None,
        "longitudinal_sha256": runs[0]["longitudinal_sha256"] if same_longitudinal else None,
        "files_match_recorded_hashes": files_ok,
    }
    output = PROJECT_ROOT / "reports/reproducibility.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if report["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()

from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from campaign_common import PROJECT_ROOT, load_config, sha256_file


def main() -> None:
    parser = argparse.ArgumentParser(description="Contrasta corsikaio con corsikaread oficial incluido en CORSIKA 7")
    parser.add_argument("--input", type=Path, default=PROJECT_ROOT / "data/full")
    args = parser.parse_args()
    config = load_config()
    runs = pd.read_parquet(args.input / "runs.parquet")
    showers = pd.read_parquet(args.input / "showers.parquet")
    run_counts = showers.groupby("run_id").agg(
        particle_rows=("n_particle_records", "sum"),
        nucleus_rows=("n_nucleus", "sum"),
        unknown_rows=("n_unknown", "sum"),
    )
    # El corsikaread Fortran de referencia cuenta códigos de partícula 1..69;
    # se elige una corrida sin núcleos/códigos desconocidos para que NTOT sea
    # directamente comparable con todas las filas de corsikaio.
    totals = run_counts.loc[
        run_counts["nucleus_rows"].eq(0) & run_counts["unknown_rows"].eq(0), "particle_rows"
    ].sort_values(kind="mergesort")
    candidates = totals[totals.gt(0)]
    if candidates.empty:
        raise SystemExit("No hay una corrida no vacia para contrastar")
    # La corrida de mediana superior evita escoger por apariencia y ejercita
    # mas de un registro binario sin generar un fort.7 innecesariamente enorme.
    run_id = candidates.index[len(candidates) // 2]
    expected = int(candidates.loc[run_id])
    run = runs.loc[runs["run_id"].eq(run_id)].iloc[0]
    raw_path = PROJECT_ROOT / run["raw_path"]

    work = PROJECT_ROOT / "_work/official_reader_crosscheck"
    if work.exists():
        resolved = work.resolve()
        if PROJECT_ROOT.resolve() not in resolved.parents:
            raise RuntimeError(f"Ruta insegura: {resolved}")
        shutil.rmtree(work)
    work.mkdir(parents=True)
    command = [
        "docker", "run", "--rm", "-i",
        "-v", f"{raw_path.parent.resolve()}:/input:ro",
        "-v", f"{work.resolve()}:/work",
        "-w", "/work",
        "--entrypoint", "/opt/corsika/src/utils/corsikaread",
        config["container"]["image"],
    ]
    completed = subprocess.run(
        command, input=f"/input/{raw_path.name}\n", text=True, capture_output=True, check=False
    )
    stdout_path = work / "corsikaread_stdout.txt"
    stdout_path.write_text(completed.stdout + completed.stderr, encoding="utf-8")
    match = re.search(r"SUMMARY FOR NTOT\s*=\s*([0-9.+\-EDed]+)", completed.stdout)
    official_count = int(float(match.group(1).replace("D", "E").replace("d", "e"))) if match else None
    report = {
        "validated_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if completed.returncode == 0 and official_count == expected else "FAIL",
        "selection_rule": (
            "corrida central al ordenar por conteo total positivo, restringida a n_nucleus=n_unknown=0 "
            "porque el corsikaread Fortran incluido cuenta codigos 1..69"
        ),
        "run_id": run_id,
        "raw_path": str(raw_path.relative_to(PROJECT_ROOT)),
        "raw_sha256": sha256_file(raw_path),
        "reader_existing": "corsikaio 0.5.0",
        "reader_official": "/opt/corsika/src/utils/corsikaread, sin thinning",
        "corsikaio_particle_rows": expected,
        "official_NTOT": official_count,
        "official_exit_code": completed.returncode,
        "official_stdout": str(stdout_path.relative_to(PROJECT_ROOT)),
    }
    output = PROJECT_ROOT / "reports/official_reader_crosscheck.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))
    if report["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()

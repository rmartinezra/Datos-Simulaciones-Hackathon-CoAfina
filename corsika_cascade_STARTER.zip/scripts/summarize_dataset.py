from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from campaign_common import PROJECT_ROOT


def read_partitioned(root: Path, columns: list[str]) -> pd.DataFrame:
    frames = [pd.read_parquet(path, columns=columns) for path in sorted(root.glob("**/*.parquet"))]
    populated = [frame for frame in frames if len(frame)]
    return pd.concat(populated, ignore_index=True) if populated else (frames[0] if frames else pd.DataFrame(columns=columns))


def main() -> None:
    full = PROJECT_ROOT / "data/full"
    showers = pd.read_parquet(full / "showers.parquet")
    metadata = json.loads((full / "dataset_metadata.json").read_text(encoding="utf-8"))
    particles = read_partitioned(full / "particles", [
        "condition_id", "particle_group", "energy_total_GeV", "distance_to_shower_axis_m",
        "time_relative_first_particle_ns",
    ])
    manifest = json.loads((PROJECT_ROOT / "manifests/production_runs.json").read_text(encoding="utf-8"))

    rows = []
    for condition_id, group in showers.groupby("condition_id", sort=True):
        part = particles.loc[particles["condition_id"].eq(condition_id)]
        counts = part["particle_group"].value_counts()
        rows.append({
            "condition_id": condition_id,
            "showers": len(group),
            "showers_without_ground_particles": int(group["n_particle_records"].eq(0).sum()),
            "particle_rows": len(part),
            "multiplicity_min": int(group["n_particle_records"].min()),
            "multiplicity_median": float(group["n_particle_records"].median()),
            "multiplicity_mean": float(group["n_particle_records"].mean()),
            "multiplicity_max": int(group["n_particle_records"].max()),
            "electromagnetic_rows": int(counts.get("electromagnetic", 0)),
            "muon_rows": int(counts.get("muon", 0)),
            "hadron_rows": int(counts.get("hadron", 0)),
            "nucleus_rows": int(counts.get("nucleus", 0)),
            "unknown_rows": int(counts.get("unknown", 0)),
            "energy_total_min_GeV": float(part["energy_total_GeV"].min()) if len(part) else None,
            "energy_total_median_GeV": float(part["energy_total_GeV"].median()) if len(part) else None,
            "energy_total_max_GeV": float(part["energy_total_GeV"].max()) if len(part) else None,
            "distance_to_axis_max_m": float(part["distance_to_shower_axis_m"].max()) if len(part) else None,
            "relative_time_max_ns": float(part["time_relative_first_particle_ns"].max()) if len(part) else None,
        })
    condition_summary = pd.DataFrame(rows)
    report_dir = PROJECT_ROOT / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    condition_summary.to_csv(report_dir / "condition_summary.csv", index=False)

    summary = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "conditions": int(showers["condition_id"].nunique()),
        "showers_complete": len(showers),
        "showers_without_ground_particles": int(showers["n_particle_records"].eq(0).sum()),
        "showers_incomplete": 0,
        "showers_failed": 0,
        "particle_rows": len(particles),
        "longitudinal_particle_rows": int(metadata["profiles_particle_rows"]),
        "longitudinal_deposit_rows": int(metadata["profiles_energy_deposit_rows"]),
        "particle_group_rows": {key: int(value) for key, value in particles["particle_group"].value_counts().items()},
        "runs": {
            "total": manifest["jobs_total"],
            "complete": manifest["jobs_complete"],
            "failed": manifest["jobs_failed"],
            "workers": manifest["workers"],
            "worker_seconds": manifest["worker_seconds"],
            "parallel_wall_equivalent_seconds": manifest["worker_seconds"] / manifest["workers"],
            "max_peak_memory_mib": manifest["max_peak_memory_mib"],
            "raw_bytes": manifest["raw_bytes"],
            "longitudinal_bytes": manifest["longitudinal_bytes"],
            "log_bytes": manifest["log_bytes"],
        },
        "condition_summary_csv": "reports/condition_summary.csv",
    }
    (report_dir / "dataset_summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

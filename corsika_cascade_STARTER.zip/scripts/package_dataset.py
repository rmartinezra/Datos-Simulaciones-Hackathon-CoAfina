from __future__ import annotations

import argparse
import gzip
import json
import shutil
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import pyarrow.parquet as pq

from campaign_common import PROJECT_ROOT, load_config, sha256_file


def read_partitioned(root: Path) -> pd.DataFrame:
    frames = [pd.read_parquet(path) for path in sorted(root.glob("**/*.parquet"))]
    populated = [frame for frame in frames if len(frame)]
    return pd.concat(populated, ignore_index=True) if populated else (frames[0] if frames else pd.DataFrame())


def safe_clean(path: Path) -> None:
    if not path.exists():
        path.mkdir(parents=True)
        return
    resolved = path.resolve()
    if PROJECT_ROOT.resolve() not in resolved.parents or resolved == PROJECT_ROOT.resolve():
        raise RuntimeError(f"Ruta fuera del proyecto: {resolved}")
    shutil.rmtree(resolved)
    path.mkdir(parents=True)


def file_record(path: Path) -> dict[str, Any]:
    resolved = path.resolve()
    record: dict[str, Any] = {
        "path": str(resolved.relative_to(PROJECT_ROOT.resolve())).replace("\\", "/"),
        "bytes": resolved.stat().st_size,
        "sha256": sha256_file(resolved),
    }
    if resolved.suffix == ".parquet":
        record["rows"] = pq.ParquetFile(resolved).metadata.num_rows
    elif resolved.name.endswith(".csv.gz"):
        with gzip.open(resolved, "rt", encoding="utf-8") as stream:
            record["rows"] = max(0, sum(1 for _ in stream) - 1)
    return record


def write_manifest(name: str, roots: list[Path], output: Path, extra: dict[str, Any] | None = None) -> dict[str, Any]:
    files: list[Path] = []
    for root in roots:
        if root.is_file():
            files.append(root)
        elif root.exists():
            files.extend(path for path in root.rglob("*") if path.is_file())
    records = [file_record(path) for path in sorted(set(files)) if path.resolve() != output.resolve()]
    manifest = {
        "name": name,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "files": records,
        "file_count": len(records),
        "total_bytes": sum(item["bytes"] for item in records),
        **(extra or {}),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    return manifest


def make_starter(full_root: Path, starter_root: Path) -> dict[str, Any]:
    config = load_config()
    safe_clean(starter_root)
    conditions = pd.read_parquet(full_root / "conditions.parquet")
    runs = pd.read_parquet(full_root / "runs.parquet")
    showers = pd.read_parquet(full_root / "showers.parquet")
    particles = read_partitioned(full_root / "particles")
    profiles = read_partitioned(full_root / "longitudinal_particles")
    deposits = read_partitioned(full_root / "longitudinal_energy_deposit")

    count = int(config["campaign"]["starter_showers_per_condition"])
    selected = (
        showers.loc[showers["status"].eq("complete")]
        .sort_values(["condition_id", "shower_id"])
        .groupby("condition_id", sort=True, as_index=False, group_keys=False)
        .head(count)
    )
    selected_ids = set(selected["shower_id"])
    selected_runs = set(selected["run_id"])
    tables = {
        "conditions": conditions.sort_values("condition_id"),
        "runs": runs[runs["run_id"].isin(selected_runs)].sort_values("run_id"),
        "showers": selected.sort_values("shower_id"),
        "particles": particles[particles["shower_id"].isin(selected_ids)].sort_values(["shower_id", "particle_row_id"]),
        "longitudinal_particles": profiles[profiles["shower_id"].isin(selected_ids)].sort_values(["shower_id", "depth_vertical_g_cm2"]),
        "longitudinal_energy_deposit": deposits[deposits["shower_id"].isin(selected_ids)].sort_values(["shower_id", "depth_vertical_g_cm2"]),
    }
    for name, frame in tables.items():
        frame.to_csv(
            starter_root / f"{name}.csv.gz", index=False,
            compression={"method": "gzip", "compresslevel": 6, "mtime": 0},
        )

    source_metadata = json.loads((full_root / "dataset_metadata.json").read_text(encoding="utf-8"))
    metadata = {
        "package": "STARTER",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "selection_rule": (
            f"Las primeras {count} cascadas completas por condition_id al ordenar shower_id; "
            "no se uso apariencia, multiplicidad ni contenido de particulas."
        ),
        "selected_shower_ids": sorted(selected_ids),
        "conditions": int(selected["condition_id"].nunique()),
        "showers": len(selected),
        "showers_without_ground_particles": int(selected["n_particle_records"].eq(0).sum()),
        "table_rows": {name: len(frame) for name, frame in tables.items()},
        "source_dataset": {
            "schema_version": source_metadata["dataset_schema_version"],
            "corsika_version": source_metadata["corsika_version"],
            "stage": source_metadata["stage"],
        },
        "campaign_configuration": config,
        "interpretation_limits": source_metadata["interpretation_limits"],
    }
    (starter_root / "metadata.json").write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    return metadata


def zip_roots(zip_path: Path, roots: list[tuple[Path, str]]) -> None:
    zip_path.parent.mkdir(parents=True, exist_ok=True)
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for root, prefix in roots:
            if not root.exists():
                continue
            if root.is_file():
                archive.write(root, f"{prefix}/{root.name}" if prefix else root.name)
                continue
            for path in sorted(root.rglob("*")):
                if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
                    archive.write(path, str(Path(prefix) / path.relative_to(root)).replace("\\", "/"))


def condition_summary(root: Path, csv_package: bool = False) -> dict[str, dict[str, int]]:
    if csv_package:
        showers = pd.read_csv(root / "showers.csv.gz")
        particles = pd.read_csv(root / "particles.csv.gz", usecols=["condition_id"])
        profiles = pd.read_csv(root / "longitudinal_particles.csv.gz", usecols=["condition_id"])
        deposits = pd.read_csv(root / "longitudinal_energy_deposit.csv.gz", usecols=["condition_id"])
    else:
        showers = pd.read_parquet(root / "showers.parquet", columns=["condition_id", "n_particle_records"])
        particles = read_partitioned(root / "particles")[["condition_id"]]
        profiles = read_partitioned(root / "longitudinal_particles")[["condition_id"]]
        deposits = read_partitioned(root / "longitudinal_energy_deposit")[["condition_id"]]
    result: dict[str, dict[str, int]] = {}
    for condition_id, frame in showers.groupby("condition_id"):
        result[condition_id] = {
            "showers": len(frame),
            "showers_without_ground_particles": int(frame["n_particle_records"].eq(0).sum()),
            "particle_rows": int(particles["condition_id"].eq(condition_id).sum()),
            "longitudinal_particle_rows": int(profiles["condition_id"].eq(condition_id).sum()),
            "longitudinal_deposit_rows": int(deposits["condition_id"].eq(condition_id).sum()),
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description="Construye paquetes STARTER y FULL")
    parser.add_argument("--full-root", type=Path, default=PROJECT_ROOT / "data/full")
    args = parser.parse_args()
    full_root = args.full_root
    starter_root = PROJECT_ROOT / "data/starter"
    packages = PROJECT_ROOT / "packages"
    packages.mkdir(parents=True, exist_ok=True)
    starter_metadata = make_starter(full_root, starter_root)

    shared_roots = [
        (PROJECT_ROOT / "README.md", ""),
        (PROJECT_ROOT / "INFORME_FINAL.md", ""),
        (PROJECT_ROOT / "DESCRIPTION_HACKATHON.md", ""),
        (PROJECT_ROOT / "LICENSE_CODE_PROPOSAL.txt", ""),
        (PROJECT_ROOT / "LICENSE_DATA_PROPOSAL.txt", ""),
        (PROJECT_ROOT / "requirements.txt", ""),
        (PROJECT_ROOT / "requirements-exploration.txt", ""),
        (PROJECT_ROOT / "config", "config"),
        (PROJECT_ROOT / "scripts", "scripts"),
        (PROJECT_ROOT / "examples", "examples"),
        (PROJECT_ROOT / "docs", "docs"),
        (PROJECT_ROOT / "reports", "reports"),
        (PROJECT_ROOT / "figures", "figures"),
        (PROJECT_ROOT / "manifests", "manifests"),
    ]
    starter_manifest_path = PROJECT_ROOT / "manifests/starter_files.json"
    starter_manifest = write_manifest(
        "corsika_cascade_STARTER", [starter_root], starter_manifest_path,
        {"selection": starter_metadata["selection_rule"], "conditions": condition_summary(starter_root, True)},
    )
    full_manifest_path = PROJECT_ROOT / "manifests/full_files.json"
    full_manifest = write_manifest(
        "corsika_cascade_FULL", [full_root], full_manifest_path,
        {"conditions": condition_summary(full_root)},
    )
    raw_manifest_path = PROJECT_ROOT / "manifests/raw_production_files.json"
    raw_manifest = write_manifest("corsika_cascade_raw_production", [PROJECT_ROOT / "data/raw/production"], raw_manifest_path)

    package_summary_path = PROJECT_ROOT / "manifests/package_summary.json"
    if package_summary_path.exists():
        package_summary_path.unlink()
    zip_roots(packages / "corsika_cascade_STARTER.zip", [(starter_root, "STARTER"), *shared_roots])
    zip_roots(packages / "corsika_cascade_FULL.zip", [(full_root, "FULL"), *shared_roots])
    summary = {
        "starter": starter_manifest,
        "full": full_manifest,
        "raw": raw_manifest,
        "archives": {
            "starter": file_record(packages / "corsika_cascade_STARTER.zip"),
            "full": file_record(packages / "corsika_cascade_FULL.zip"),
        },
    }
    package_summary_path.write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(json.dumps({
        "starter_showers": starter_metadata["showers"],
        "starter_bytes_uncompressed": starter_manifest["total_bytes"],
        "full_bytes_uncompressed": full_manifest["total_bytes"],
        "raw_bytes": raw_manifest["total_bytes"],
        "starter_zip_bytes": summary["archives"]["starter"]["bytes"],
        "full_zip_bytes": summary["archives"]["full"]["bytes"],
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

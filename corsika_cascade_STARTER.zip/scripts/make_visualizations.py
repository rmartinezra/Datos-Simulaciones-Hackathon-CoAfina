from __future__ import annotations

import argparse
import json
import math
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from campaign_common import PROJECT_ROOT


COLORS = {
    "electromagnetic": "#2878B5",
    "muon": "#D95319",
    "hadron": "#2E8B57",
    "nucleus": "#8E5EA2",
    "unknown": "#777777",
}


def read_partitioned(root: Path) -> pd.DataFrame:
    frames = [pd.read_parquet(path) for path in sorted(root.glob("**/*.parquet"))]
    populated = [frame for frame in frames if len(frame)]
    return pd.concat(populated, ignore_index=True) if populated else (frames[0] if frames else pd.DataFrame())


def condition_label(condition_id: str) -> str:
    primary, energy, zenith, _azimuth = condition_id.split("_")
    energy_value = int(energy[1:-3])
    energy_label = f"{energy_value // 1000} TeV" if energy_value >= 1000 else f"{energy_value} GeV"
    return f"{'γ' if primary == 'gamma' else 'p'} · {energy_label} · {int(zenith[1:])}°"


def ordered_conditions(conditions: pd.DataFrame) -> list[str]:
    return conditions.sort_values(["primary_code", "energy_total_GeV", "zenith_deg"])["condition_id"].tolist()


def save(fig: plt.Figure, output: Path) -> None:
    fig.savefig(output, dpi=180, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def boxplot_by_condition(ax: plt.Axes, showers: pd.DataFrame, conditions: list[str], column: str) -> None:
    values = [showers.loc[showers["condition_id"].eq(condition), column].dropna().to_numpy() for condition in conditions]
    parts = ax.boxplot(values, patch_artist=True, showfliers=True, widths=0.65)
    for index, patch in enumerate(parts["boxes"]):
        patch.set_facecolor("#7DB7D8" if conditions[index].startswith("gamma") else "#E9A978")
        patch.set_alpha(0.85)
    ax.set_xticks(range(1, len(conditions) + 1), [condition_label(item) for item in conditions], rotation=55, ha="right")
    ax.grid(axis="y", alpha=0.25)


def deterministic_subset(frame: pd.DataFrame, limit: int) -> tuple[pd.DataFrame, int]:
    if len(frame) <= limit:
        return frame, 1
    step = math.ceil(len(frame) / limit)
    return frame.iloc[::step].head(limit), step


def make_figures(full_root: Path, output: Path) -> dict[str, Any]:
    if output.exists():
        resolved = output.resolve()
        if PROJECT_ROOT.resolve() not in resolved.parents:
            raise RuntimeError(f"Ruta de figuras fuera del proyecto: {resolved}")
        shutil.rmtree(output)
    output.mkdir(parents=True, exist_ok=True)

    conditions_df = pd.read_parquet(full_root / "conditions.parquet")
    showers = pd.read_parquet(full_root / "showers.parquet")
    particles = read_partitioned(full_root / "particles")
    profiles = read_partitioned(full_root / "longitudinal_particles")
    conditions = ordered_conditions(conditions_df)
    metadata: dict[str, Any] = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "source": str(full_root.resolve().relative_to(PROJECT_ROOT.resolve())),
        "normalization": {},
        "subsets": {},
        "files": [],
    }

    fig, ax = plt.subplots(figsize=(13, 6.5), constrained_layout=True)
    transformed = showers.assign(log1p_multiplicity=np.log10(1 + showers["n_particle_records"]))
    boxplot_by_condition(ax, transformed, conditions, "log1p_multiplicity")
    ax.set_ylabel("log₁₀(1 + registros al nivel de observación)")
    ax.set_title("Fluctuación de multiplicidad entre cascadas")
    ax.text(0.01, 0.98, "Cada punto estadístico es una cascada; se conservan los ceros.",
            transform=ax.transAxes, va="top", fontsize=9)
    path = output / "01_multiplicidad_por_condicion.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["normalization"][path.name] = "boxplot entre cascadas de log10(1+n); sin ponderacion"

    composition = particles.groupby(["condition_id", "particle_group"]).size().unstack(fill_value=0).reindex(conditions)
    composition_fraction = composition.div(composition.sum(axis=1).replace(0, np.nan), axis=0).fillna(0)
    fig, ax = plt.subplots(figsize=(13, 6.5), constrained_layout=True)
    bottom = np.zeros(len(composition_fraction))
    for group in ["electromagnetic", "muon", "hadron", "nucleus", "unknown"]:
        if group not in composition_fraction:
            continue
        values = composition_fraction[group].to_numpy()
        ax.bar(range(len(conditions)), values, bottom=bottom, color=COLORS[group], label=group)
        bottom += values
    ax.set_xticks(range(len(conditions)), [condition_label(item) for item in conditions], rotation=55, ha="right")
    ax.set_ylim(0, 1)
    ax.set_ylabel("Fracción de registros de partículas")
    ax.set_title("Composición secundaria registrada al nivel de observación")
    ax.legend(ncols=5, loc="upper center", bbox_to_anchor=(0.5, 1.12))
    ax.grid(axis="y", alpha=0.2)
    path = output / "02_composicion_secundarios.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["normalization"][path.name] = "fraccion de filas reales por condicion; peso=1, sin thinning"

    positive = showers.loc[showers["n_particle_records"].gt(0)].sort_values(["n_particle_records", "shower_id"])
    contrast_ids = [positive.iloc[0]["shower_id"], positive.iloc[-1]["shower_id"]]
    selected = showers.set_index("shower_id").loc[contrast_ids]
    max_extent = 0.0
    selected_frames: dict[str, pd.DataFrame] = {}
    subset_steps: dict[str, int] = {}
    for shower_id in contrast_ids:
        frame = particles.loc[particles["shower_id"].eq(shower_id)].sort_values("particle_row_id")
        frame, step = deterministic_subset(frame, 25_000)
        selected_frames[shower_id] = frame
        subset_steps[shower_id] = step
        max_extent = max(max_extent, float(np.nanmax(np.abs(frame[["x_cartesian_m", "y_cartesian_m"]].to_numpy()))))
    fig, axes = plt.subplots(1, 2, figsize=(13, 6.2), constrained_layout=True)
    for ax, shower_id in zip(axes, contrast_ids):
        frame = selected_frames[shower_id]
        for group, group_frame in frame.groupby("particle_group", sort=False):
            ax.scatter(group_frame["x_cartesian_m"], group_frame["y_cartesian_m"], s=6, alpha=0.5,
                       color=COLORS.get(group, COLORS["unknown"]), label=group, linewidths=0)
        row = selected.loc[shower_id]
        ax.set_title(f"{condition_label(row['condition_id'])}\n{int(row['n_particle_records']):,} registros")
        ax.set_xlabel("x cartesiana: norte [m]")
        ax.set_ylabel("y cartesiana: oeste [m]")
        ax.set_aspect("equal", adjustable="box")
        ax.set_xlim(-max_extent * 1.05, max_extent * 1.05)
        ax.set_ylim(-max_extent * 1.05, max_extent * 1.05)
        ax.grid(alpha=0.2)
    handles, labels = axes[-1].get_legend_handles_labels()
    fig.legend(handles, labels, ncols=max(1, len(labels)), loc="lower center", bbox_to_anchor=(0.5, -0.04))
    fig.suptitle("Huellas contrastantes: mínima multiplicidad positiva y máxima multiplicidad", y=1.07)
    path = output / "03_huellas_contrastantes.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["subsets"][path.name] = {
        "selection": "minimo positivo y maximo n_particle_records; desempate por shower_id",
        "shower_ids": contrast_ids,
        "point_subsampling": {key: f"cada {value} filas, desde particle_row_id=0" for key, value in subset_steps.items()},
        "common_xy_extent_m": max_extent,
    }

    per_shower_radius = particles.groupby(["shower_id", "condition_id"])["distance_to_shower_axis_m"].median().rename("median_radius_m").reset_index()
    fig, ax = plt.subplots(figsize=(13, 6.5), constrained_layout=True)
    boxplot_by_condition(ax, per_shower_radius, conditions, "median_radius_m")
    ax.set_yscale("log")
    ax.set_ylabel("Mediana por cascada de distancia al eje [m]")
    ax.set_title("Distribución radial y fluctuación entre cascadas")
    path = output / "04_distribucion_radial.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["normalization"][path.name] = "primero mediana de filas por cascada; luego boxplot entre cascadas no vacias"

    radial_subsets: dict[str, int] = {}
    fig, axes = plt.subplots(2, 3, figsize=(15, 9), sharey=True, constrained_layout=True)
    primary_energy_pairs = [("gamma", 100.0), ("gamma", 1000.0), ("gamma", 10000.0),
                            ("proton", 100.0), ("proton", 1000.0), ("proton", 10000.0)]
    for ax, (primary, energy) in zip(axes.ravel(), primary_energy_pairs):
        for zenith, color in [(0.0, "#2878B5"), (30.0, "#D95319")]:
            condition = conditions_df.loc[
                conditions_df["primary"].eq(primary)
                & conditions_df["energy_total_GeV"].eq(energy)
                & conditions_df["zenith_deg"].eq(zenith), "condition_id"
            ].iloc[0]
            frame = particles.loc[particles["condition_id"].eq(condition)].sort_values(["shower_id", "particle_row_id"])
            frame, step = deterministic_subset(frame, 50_000)
            radial_subsets[condition] = step
            values = np.sort(frame["distance_to_shower_axis_m"].dropna().to_numpy())
            if len(values):
                ax.plot(
                    values, np.arange(1, len(values) + 1) / len(values), color=color,
                    label=f"{int(zenith)}°", marker=".", markersize=3,
                    markevery=max(1, len(values) // 50),
                )
        energy_label = f"{int(energy/1000)} TeV" if energy >= 1000 else f"{int(energy)} GeV"
        ax.set_title(f"{'γ' if primary == 'gamma' else 'p'} · {energy_label}")
        ax.set_xscale("symlog", linthresh=1.0)
        ax.grid(alpha=0.2)
    axes[0, 0].legend(title="Cenit")
    fig.supxlabel("Distancia perpendicular al eje [m]")
    fig.supylabel("Fracción acumulada de registros")
    fig.suptitle("Distribuciones radiales de partículas registradas", fontsize=15)
    path = output / "04b_distribucion_radial_registros.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["normalization"][path.name] = "CDF por filas de particulas dentro de cada condicion; peso=1"
    metadata["subsets"][path.name] = {key: f"cada {value} filas desde el orden (shower_id, particle_row_id)" for key, value in radial_subsets.items()}

    per_shower_energy = particles.groupby(["shower_id", "condition_id"])["energy_total_GeV"].median().rename("median_energy_GeV").reset_index()
    fig, ax = plt.subplots(figsize=(13, 6.5), constrained_layout=True)
    boxplot_by_condition(ax, per_shower_energy, conditions, "median_energy_GeV")
    ax.set_yscale("log")
    ax.set_ylabel("Mediana por cascada de energía total secundaria [GeV]")
    ax.set_title("Energía de secundarios registrados")
    path = output / "05_energia_secundarios.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["normalization"][path.name] = "energia total derivada de p y masa verificada; resumen por cascada"

    energy_subsets: dict[str, int] = {}
    fig, axes = plt.subplots(2, 3, figsize=(15, 9), sharey=True, constrained_layout=True)
    for ax, (primary, energy) in zip(axes.ravel(), primary_energy_pairs):
        for zenith, color in [(0.0, "#2878B5"), (30.0, "#D95319")]:
            condition = conditions_df.loc[
                conditions_df["primary"].eq(primary)
                & conditions_df["energy_total_GeV"].eq(energy)
                & conditions_df["zenith_deg"].eq(zenith), "condition_id"
            ].iloc[0]
            frame = particles.loc[particles["condition_id"].eq(condition)].sort_values(["shower_id", "particle_row_id"])
            frame, step = deterministic_subset(frame, 50_000)
            energy_subsets[condition] = step
            values = np.sort(frame["energy_total_GeV"].dropna().to_numpy())
            if len(values):
                ax.plot(
                    values, np.arange(1, len(values) + 1) / len(values), color=color,
                    label=f"{int(zenith)}°", marker=".", markersize=3,
                    markevery=max(1, len(values) // 50),
                )
        energy_label = f"{int(energy/1000)} TeV" if energy >= 1000 else f"{int(energy)} GeV"
        ax.set_title(f"{'γ' if primary == 'gamma' else 'p'} · {energy_label}")
        ax.set_xscale("log")
        ax.grid(alpha=0.2)
    axes[0, 0].legend(title="Cenit")
    fig.supxlabel("Energía total secundaria derivada [GeV]")
    fig.supylabel("Fracción acumulada de registros")
    fig.suptitle("Distribuciones de energía de partículas registradas", fontsize=15)
    path = output / "05b_distribucion_energia_registros.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["normalization"][path.name] = "CDF por filas con masa verificada dentro de cada condicion; peso=1"
    metadata["subsets"][path.name] = {key: f"cada {value} filas desde el orden (shower_id, particle_row_id)" for key, value in energy_subsets.items()}

    timing_id = positive.iloc[-1]["shower_id"]
    timing = particles.loc[particles["shower_id"].eq(timing_id)].sort_values("particle_row_id")
    timing_subset, timing_step = deterministic_subset(timing, 40_000)
    fig, ax = plt.subplots(figsize=(9, 6.5), constrained_layout=True)
    for group, frame in timing_subset.groupby("particle_group", sort=False):
        ax.scatter(frame["distance_to_shower_axis_m"], frame["time_relative_first_particle_ns"],
                   s=5, alpha=0.35, color=COLORS.get(group, COLORS["unknown"]), label=group, linewidths=0)
    ax.set_xscale("symlog", linthresh=1.0)
    ax.set_yscale("symlog", linthresh=1.0)
    ax.set_xlabel("Distancia perpendicular al eje [m]")
    ax.set_ylabel("Tiempo relativo al primer registro de la cascada [ns]")
    ax.set_title(f"Tiempo relativo frente a distancia · {timing_id}")
    ax.legend()
    ax.grid(alpha=0.2)
    path = output / "06_tiempo_vs_distancia.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["subsets"][path.name] = {"shower_id": timing_id, "row_step": timing_step, "max_points": 40_000}
    metadata["normalization"][path.name] = "tiempo CORSIKA conservado; relativo = t - min(t) dentro de la cascada"

    fig, axes = plt.subplots(2, 3, figsize=(15, 9), sharex=True, constrained_layout=True)
    for ax, (primary, energy) in zip(axes.ravel(), primary_energy_pairs):
        for zenith, color in [(0.0, "#2878B5"), (30.0, "#D95319")]:
            condition = conditions_df.loc[
                conditions_df["primary"].eq(primary)
                & conditions_df["energy_total_GeV"].eq(energy)
                & conditions_df["zenith_deg"].eq(zenith), "condition_id"
            ].iloc[0]
            subset = profiles.loc[profiles["condition_id"].eq(condition), ["shower_id", "depth_vertical_g_cm2", "charged"]]
            pivot = subset.pivot(index="depth_vertical_g_cm2", columns="shower_id", values="charged").sort_index()
            median = pivot.median(axis=1)
            low = pivot.quantile(0.10, axis=1)
            high = pivot.quantile(0.90, axis=1)
            ax.plot(pivot.index, median, color=color, label=f"{int(zenith)}°")
            ax.fill_between(pivot.index, low, high, color=color, alpha=0.18)
        label_energy = f"{int(energy/1000)} TeV" if energy >= 1000 else f"{int(energy)} GeV"
        ax.set_title(f"{'γ' if primary == 'gamma' else 'p'} · {label_energy}")
        ax.set_yscale("symlog", linthresh=1.0)
        ax.grid(alpha=0.2)
    axes[0, 0].legend(title="Cenit")
    fig.supxlabel("Profundidad atmosférica vertical [g/cm²]")
    fig.supylabel("Partículas cargadas (mediana; banda 10–90 % entre cascadas)")
    fig.suptitle("Desarrollo longitudinal", fontsize=15)
    path = output / "07_perfiles_longitudinales.png"
    save(fig, path); metadata["files"].append(path.name)
    metadata["normalization"][path.name] = "mediana y percentiles 10-90 entre cascadas, por profundidad y condicion"

    metadata_path = output / "figure_metadata.json"
    metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(description="Genera las visualizaciones estaticas del dataset")
    parser.add_argument("--input", type=Path, default=PROJECT_ROOT / "data/full")
    parser.add_argument("--output", type=Path, default=PROJECT_ROOT / "figures")
    args = parser.parse_args()
    metadata = make_figures(args.input, args.output)
    print(json.dumps({"figures": metadata["files"], "output": str(args.output)}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

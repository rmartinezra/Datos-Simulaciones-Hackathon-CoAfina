from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any


PROJECT_ROOT = Path(__file__).resolve().parents[1]
CONFIG_PATH = PROJECT_ROOT / "config" / "campaign.json"


def load_config() -> dict[str, Any]:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def deterministic_seed(stage: str, condition_id: str, block_index: int, sequence: int) -> int:
    payload = f"corsika-cascade-dataset|{stage}|{condition_id}|{block_index}|{sequence}".encode()
    value = int.from_bytes(hashlib.sha256(payload).digest()[:8], "big")
    return 1 + value % 900_000_000


def build_card(
    config: dict[str, Any],
    condition: dict[str, Any],
    run_number: int,
    first_event_number: int,
    n_showers: int,
    stage: str,
    block_index: int,
    seeds: tuple[int, int] | None = None,
) -> str:
    p = config["physics"]
    if seeds is None:
        seeds = (
            deterministic_seed(stage, condition["condition_id"], block_index, 1),
            deterministic_seed(stage, condition["condition_id"], block_index, 2),
        )
    lines = [
        f"RUNNR   {run_number}",
        f"EVTNR   {first_event_number}",
        f"NSHOW   {n_showers}",
        f"PRMPAR  {condition['primary_code']}",
        f"ERANGE  {condition['energy_total_GeV']:.9E} {condition['energy_total_GeV']:.9E}",
        "ESLOPE  0.0",
        f"THETAP  {condition['zenith_deg']:.6f} {condition['zenith_deg']:.6f}",
        f"PHIP    {p['azimuth_deg']:.6f} {p['azimuth_deg']:.6f}",
        f"SEED    {seeds[0]} 0 0",
        f"SEED    {seeds[1]} 0 0",
        f"ATMOD   {p['atmosphere_model_id']}",
        f"OBSLEV  {p['observation_level_cm_asl']:.9E}",
        f"MAGNET  {p['magnetic_field_horizontal_north_uT']:.6f} {p['magnetic_field_vertical_down_uT']:.6f}",
        "FIXCHI  0.0",
        f"HILOW   {p['transition_energy_GeV']:.6f}",
        "HADFLG  0 0 0 0 0 2",
        (
            "ECUTS   "
            f"{p['energy_cut_hadron_kinetic_GeV']:.9g} "
            f"{p['energy_cut_muon_kinetic_GeV']:.9g} "
            f"{p['energy_cut_electron_kinetic_GeV']:.9g} "
            f"{p['energy_cut_photon_GeV']:.9g}"
        ),
        "ELMFLG  T T",
        "STEPFC  1.0",
        "MUMULT  T",
        "MUADDI  F",
        "RADNKG  2.000000E4",
        f"ARRANG  {p['array_rotation_deg']:.6f}",
        "CURVOUT T",
        f"LONGI   T {p['longitudinal_step_vertical_g_cm2']:.6f} T T",
        "PAROUT  T F",
        "MAXPRT  1",
        "DIRECT  /out/",
        "USER    hackathon",
        "DEBUG   F 6 F 1000000",
        "EXIT",
    ]
    return "\n".join(lines) + "\n"


def parse_memory_mib(value: str) -> float | None:
    if not value:
        return None
    used = value.split("/", 1)[0].strip()
    match = re.fullmatch(r"([0-9.]+)\s*([KMGTP]?i?B)", used, re.IGNORECASE)
    if not match:
        return None
    amount = float(match.group(1))
    unit = match.group(2).lower()
    factors = {
        "b": 1 / (1024**2),
        "kb": 1000 / (1024**2),
        "kib": 1 / 1024,
        "mb": 1000**2 / 1024**2,
        "mib": 1.0,
        "gb": 1000**3 / 1024**2,
        "gib": 1024.0,
        "tb": 1000**4 / 1024**2,
        "tib": 1024.0**2,
    }
    return amount * factors[unit]


def read_wsl_memory_total_mib() -> float:
    text = Path("/proc/meminfo").read_text(encoding="utf-8")
    match = re.search(r"^MemTotal:\s+(\d+)\s+kB$", text, re.MULTILINE)
    if not match:
        raise RuntimeError("No se pudo leer MemTotal de /proc/meminfo")
    return int(match.group(1)) / 1024


def finite_or_none(value: float) -> float | None:
    return float(value) if math.isfinite(float(value)) else None

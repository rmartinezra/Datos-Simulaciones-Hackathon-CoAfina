from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

from campaign_common import PROJECT_ROOT, load_config
from run_campaign import build_jobs, job_directory, run_job, summarize_stage


def _assert_within(path: Path, parent: Path) -> None:
    resolved_path = path.resolve()
    resolved_parent = parent.resolve()
    if not resolved_path.is_relative_to(resolved_parent):
        raise RuntimeError(f"Ruta fuera del arbol autorizado: {resolved_path}")


def _unique_backup_path(root: Path, run_id: str) -> Path:
    candidate = root / f"{run_id}_before_clean_rerun"
    suffix = 1
    while candidate.exists():
        candidate = root / f"{run_id}_before_clean_rerun_{suffix:02d}"
        suffix += 1
    return candidate


def main() -> None:
    manifest_path = PROJECT_ROOT / "manifests/production_runs.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    anomalous = [
        item for item in manifest["runs"]
        if item["status"] == "complete" and float(item["wall_seconds"]) > 600.0
    ]
    plan = json.loads((PROJECT_ROOT / "manifests/production_plan.json").read_text(encoding="utf-8"))
    jobs = {
        job.run_id: job
        for job in build_jobs(load_config(), "production", int(plan["planned_events_per_condition"]))
    }
    raw_root = PROJECT_ROOT / "data/raw/production"
    backup_root = PROJECT_ROOT / "_work/clock_metric_backups"
    backup_root.mkdir(parents=True, exist_ok=True)
    actions = []
    for old in anomalous:
        job = jobs[old["run_id"]]
        directory = job_directory(job)
        _assert_within(directory, raw_root)
        backup_directory = _unique_backup_path(backup_root, job.run_id)
        _assert_within(backup_directory, backup_root)
        current_result_path = directory / "run.json"
        if current_result_path.exists():
            current_result = json.loads(current_result_path.read_text(encoding="utf-8"))
            pre_rerun_status = current_result.get("status", "unknown")
        else:
            pre_rerun_status = "missing_run_json"
        if not directory.is_dir():
            raise RuntimeError(f"No existe el directorio que se va a respaldar: {directory}")
        shutil.move(str(directory), str(backup_directory))
        try:
            new = run_job(job, load_config(), resume=False)
        except Exception:
            if directory.exists():
                failed_directory = backup_directory.with_name(backup_directory.name + "_failed_rerun")
                shutil.move(str(directory), str(failed_directory))
            shutil.move(str(backup_directory), str(directory))
            raise
        hashes_identical = (
            old["card_sha256"] == new["card_sha256"]
            and old["raw_sha256"] == new["raw_sha256"]
            and old["longitudinal_sha256"] == new["longitudinal_sha256"]
        )
        actions.append({
            "run_id": job.run_id,
            "old_wall_seconds_civil_clock": old["wall_seconds"],
            "new_wall_seconds_monotonic": new["wall_seconds"],
            "hashes_identical": hashes_identical,
            "pre_clean_rerun_status": pre_rerun_status,
            "backup_directory": str(backup_directory.relative_to(PROJECT_ROOT)),
            "raw_sha256": new["raw_sha256"],
            "longitudinal_sha256": new["longitudinal_sha256"],
        })
        if new["status"] != "complete" or not hashes_identical:
            failed_directory = backup_directory.with_name(backup_directory.name + "_failed_rerun")
            if directory.exists():
                shutil.move(str(directory), str(failed_directory))
            shutil.move(str(backup_directory), str(directory))
            raise RuntimeError(f"La reparacion de {job.run_id} no reprodujo exactamente los datos")

    all_results = [
        json.loads(path.read_text(encoding="utf-8"))
        for path in sorted((PROJECT_ROOT / "data/raw/production").glob("**/run.json"))
    ]
    all_results.sort(key=lambda item: (item["condition_index"], item["block_index"]))
    rebuilt = summarize_stage("production", all_results, int(manifest["workers"]))
    report = {
        "repaired_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if all(item["hashes_identical"] for item in actions) else "FAIL",
        "criterion": "wall_seconds > 600 s en trabajos cuyo piloto predecia menos de 2 min",
        "anomalies_found": len(anomalous),
        "actions": actions,
        "rebuilt_jobs": rebuilt["jobs_total"],
        "rebuilt_jobs_complete": rebuilt["jobs_complete"],
        "rebuilt_jobs_failed": rebuilt["jobs_failed"],
        "rebuilt_events": rebuilt["events_complete"],
        "rebuilt_worker_seconds": rebuilt["worker_seconds"],
    }
    output = PROJECT_ROOT / "reports/clock_metric_repair.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()

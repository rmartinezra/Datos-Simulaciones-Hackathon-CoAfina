from __future__ import annotations

import argparse
import json
import math
import shutil
import struct
import warnings
from collections import Counter
from pathlib import Path
from typing import Any, Iterable

import corsikaio
import numpy as np
import pandas as pd

from campaign_common import PROJECT_ROOT, load_config, sha256_file


EARTH_RADIUS_CM = 637_131_500.0

# Códigos CORSIKA verificados contra la tabla 4 de CORSIKA 7.8010. Las masas
# son las de `parmas` en el lector oficial local corsikaread.cpp y sólo se
# incluyen donde la conversión de especie es inequívoca. Las especies
# desconocidas quedan nulas.
PARTICLES: dict[int, dict[str, Any]] = {
    1: {"species": "gamma", "pdg": 22, "mass_GeV": 0.0, "group": "electromagnetic"},
    2: {"species": "positron", "pdg": -11, "mass_GeV": 0.000510998902, "group": "electromagnetic"},
    3: {"species": "electron", "pdg": 11, "mass_GeV": 0.000510998902, "group": "electromagnetic"},
    5: {"species": "muon_plus", "pdg": -13, "mass_GeV": 0.105658357, "group": "muon"},
    6: {"species": "muon_minus", "pdg": 13, "mass_GeV": 0.105658357, "group": "muon"},
    7: {"species": "pion_zero", "pdg": 111, "mass_GeV": 0.1349766, "group": "hadron"},
    8: {"species": "pion_plus", "pdg": 211, "mass_GeV": 0.13957018, "group": "hadron"},
    9: {"species": "pion_minus", "pdg": -211, "mass_GeV": 0.13957018, "group": "hadron"},
    10: {"species": "kaon_long_zero", "pdg": 130, "mass_GeV": 0.497672, "group": "hadron"},
    11: {"species": "kaon_plus", "pdg": 321, "mass_GeV": 0.493677, "group": "hadron"},
    12: {"species": "kaon_minus", "pdg": -321, "mass_GeV": 0.493677, "group": "hadron"},
    13: {"species": "neutron", "pdg": 2112, "mass_GeV": 0.93956533, "group": "hadron"},
    14: {"species": "proton", "pdg": 2212, "mass_GeV": 0.93827200, "group": "hadron"},
    15: {"species": "antiproton", "pdg": -2212, "mass_GeV": 0.93827200, "group": "hadron"},
    16: {"species": "kaon_short_zero", "pdg": 310, "mass_GeV": 0.497672, "group": "hadron"},
    17: {"species": "eta", "pdg": 221, "mass_GeV": 0.54730, "group": "hadron"},
    18: {"species": "lambda", "pdg": 3122, "mass_GeV": 1.115683, "group": "hadron"},
    19: {"species": "sigma_plus", "pdg": 3222, "mass_GeV": 1.18937, "group": "hadron"},
    20: {"species": "sigma_zero", "pdg": 3212, "mass_GeV": 1.192642, "group": "hadron"},
    21: {"species": "sigma_minus", "pdg": 3112, "mass_GeV": 1.197449, "group": "hadron"},
    22: {"species": "xi_zero", "pdg": 3322, "mass_GeV": 1.31483, "group": "hadron"},
    23: {"species": "xi_minus", "pdg": 3312, "mass_GeV": 1.32131, "group": "hadron"},
    24: {"species": "omega_minus", "pdg": 3334, "mass_GeV": 1.67245, "group": "hadron"},
    25: {"species": "antineutron", "pdg": -2112, "mass_GeV": 0.93956533, "group": "hadron"},
    26: {"species": "antilambda", "pdg": -3122, "mass_GeV": 1.115683, "group": "hadron"},
    27: {"species": "antisigma_minus", "pdg": -3222, "mass_GeV": 1.18937, "group": "hadron"},
    28: {"species": "antisigma_zero", "pdg": -3212, "mass_GeV": 1.192642, "group": "hadron"},
    29: {"species": "antisigma_plus", "pdg": -3112, "mass_GeV": 1.197449, "group": "hadron"},
    30: {"species": "antixi_zero", "pdg": -3322, "mass_GeV": 1.31483, "group": "hadron"},
    31: {"species": "antixi_plus", "pdg": -3312, "mass_GeV": 1.32131, "group": "hadron"},
    32: {"species": "antiomega_plus", "pdg": -3334, "mass_GeV": 1.67245, "group": "hadron"}
}


PARTICLE_COLUMNS = [
    "shower_id", "particle_row_id", "condition_id", "run_id", "corsika_run_number",
    "corsika_event_number", "particle_description_original", "corsika_particle_code",
    "hadronic_generation", "observation_level_index", "species", "pdg_id", "particle_group",
    "mass_GeV_c2", "px_GeV_c", "py_GeV_c", "pz_down_GeV_c", "momentum_GeV_c",
    "energy_total_GeV", "energy_kinetic_GeV", "direction_north", "direction_west",
    "direction_down", "direction_zenith_deg", "direction_azimuth_deg", "x_output_cm",
    "y_output_cm", "time_corsika_ns", "time_relative_first_particle_ns",
    "x_cartesian_m", "y_cartesian_m", "z_cartesian_local_m", "radial_arc_m",
    "radial_chord_m", "distance_to_shower_axis_m", "statistical_weight",
    "statistical_weight_source", "is_derived_energy", "is_derived_coordinate"
]


LONG_PARTICLE_COLUMNS = [
    "shower_id", "condition_id", "run_id", "corsika_run_number", "corsika_event_number",
    "depth_vertical_g_cm2", "gammas", "positrons", "electrons", "mu_plus", "mu_minus",
    "hadrons", "charged", "nuclei", "cherenkov"
]


LONG_DEPOSIT_COLUMNS = [
    "shower_id", "condition_id", "run_id", "corsika_run_number", "corsika_event_number",
    "depth_vertical_g_cm2", "gamma_cut_GeV", "em_ionization_GeV", "em_cut_GeV",
    "muon_ionization_GeV", "muon_cut_GeV", "hadron_ionization_GeV", "hadron_cut_GeV",
    "neutrino_GeV", "sum_deposit_GeV"
]


def inspect_binary_layout(path: Path) -> dict[str, Any]:
    size = path.stat().st_size
    candidates: list[tuple[str, int, int]] = []
    with path.open("rb") as stream:
        prefix = stream.read(8)
    for endian, symbol in [("little", "<"), ("big", ">")]:
        if len(prefix) >= 4:
            marker4 = struct.unpack(symbol + "I", prefix[:4])[0]
            if marker4 in (22_932, 26_208):
                candidates.append((endian, 4, marker4))
        if len(prefix) >= 8:
            marker8 = struct.unpack(symbol + "Q", prefix)[0]
            if marker8 in (22_932, 26_208):
                candidates.append((endian, 8, marker8))
    if len(candidates) != 1:
        raise ValueError(f"Marcador de registro ambiguo o no reconocido en {path}: {candidates}")
    endian, marker_bytes, payload_bytes = candidates[0]
    symbol = "<" if endian == "little" else ">"
    records = 0
    tags: Counter[str] = Counter()
    with path.open("rb") as stream:
        while stream.tell() < size:
            lead = stream.read(marker_bytes)
            if len(lead) != marker_bytes:
                raise ValueError(f"Marcador inicial truncado en {path}")
            marker_format = symbol + ("I" if marker_bytes == 4 else "Q")
            length = struct.unpack(marker_format, lead)[0]
            if length != payload_bytes:
                raise ValueError(f"Longitud de registro inesperada {length} en {path}")
            payload = stream.read(length)
            trail = stream.read(marker_bytes)
            if len(payload) != length or len(trail) != marker_bytes:
                raise ValueError(f"Registro truncado en {path}")
            if struct.unpack(marker_format, trail)[0] != length:
                raise ValueError(f"Marcadores Fortran no coinciden en {path}")
            subblock_bytes = 1092 if length == 22_932 else 1248
            for offset in range(0, length, subblock_bytes):
                tag = payload[offset:offset + 4].decode("ascii", errors="ignore")
                if tag in {"RUNH", "EVTH", "LONG", "EVTE", "RUNE"}:
                    tags[tag] += 1
            records += 1
    return {
        "byte_order": endian,
        "fortran_record_marker_bytes": marker_bytes,
        "record_payload_bytes": payload_bytes,
        "subblock_float_words": 273 if payload_bytes == 22_932 else 312,
        "particle_float_words": 7 if payload_bytes == 22_932 else 8,
        "thinning_format": payload_bytes == 26_208,
        "records": records,
        "tags": dict(tags),
        "file_bytes": size,
    }


def species_info(code: int) -> dict[str, Any]:
    if code in PARTICLES:
        return PARTICLES[code]
    if 200 <= code <= 5699:
        mass_number, atomic_number = divmod(code, 100)
        if 2 <= mass_number <= 56 and 0 < atomic_number <= mass_number:
            return {
                "species": f"nucleus_A{mass_number}_Z{atomic_number}",
                "pdg": None,
                "mass_GeV": None,
                "group": "nucleus",
            }
    return {"species": None, "pdg": None, "mass_GeV": None, "group": "unknown"}


def particle_frame(
    array: np.ndarray,
    shower_id: str,
    condition_id: str,
    run_id: str,
    run_number: int,
    event_number: int,
    observation_height_cm: float,
    primary_zenith_rad: float,
    primary_azimuth_rad: float,
) -> pd.DataFrame:
    if len(array) == 0:
        return pd.DataFrame(columns=PARTICLE_COLUMNS)
    description = np.rint(array["particle_description"]).astype(np.int64)
    if np.any(description <= 0):
        raise ValueError("Se encontraron registros auxiliares o negativos con MUADDI/EMADDI desactivado")
    codes = description // 1000
    remainder = description % 1000
    generation = remainder // 10
    observation_level = remainder % 10
    info = [species_info(int(code)) for code in codes]
    mass = np.array([item["mass_GeV"] if item["mass_GeV"] is not None else np.nan for item in info])
    px = array["px"].astype(np.float64)
    py = array["py"].astype(np.float64)
    pz = array["pz"].astype(np.float64)
    momentum = np.sqrt(px * px + py * py + pz * pz)
    energy = np.where(np.isfinite(mass), np.sqrt(momentum * momentum + mass * mass), np.nan)
    kinetic = energy - mass
    safe_momentum = np.where(momentum > 0, momentum, np.nan)
    direction_north = px / safe_momentum
    direction_west = py / safe_momentum
    direction_down = pz / safe_momentum
    direction_zenith = np.degrees(np.arccos(np.clip(direction_down, -1.0, 1.0)))
    direction_azimuth = np.degrees(np.arctan2(direction_west, direction_north))

    x_prime = array["x"].astype(np.float64)
    y_prime = array["y"].astype(np.float64)
    arc_cm = np.hypot(x_prime, y_prime)
    surface_theta = arc_cm / (EARTH_RADIUS_CM + observation_height_cm)
    surface_phi = np.arctan2(y_prime, x_prime)
    d_cm = (EARTH_RADIUS_CM + observation_height_cm) * np.sin(surface_theta)
    x_cart_cm = d_cm * np.cos(surface_phi)
    y_cart_cm = d_cm * np.sin(surface_phi)
    z_cart_cm = (EARTH_RADIUS_CM + observation_height_cm) * np.cos(surface_theta) - EARTH_RADIUS_CM
    radial_chord_m = np.hypot(x_cart_cm, y_cart_cm) / 100.0
    x_cart_m = x_cart_cm / 100.0
    y_cart_m = y_cart_cm / 100.0
    z_cart_m = z_cart_cm / 100.0

    core_z_m = observation_height_cm / 100.0
    rel = np.column_stack([x_cart_m, y_cart_m, z_cart_m - core_z_m])
    shower_direction = np.array([
        math.sin(primary_zenith_rad) * math.cos(primary_azimuth_rad),
        math.sin(primary_zenith_rad) * math.sin(primary_azimuth_rad),
        -math.cos(primary_zenith_rad),
    ])
    along = rel @ shower_direction
    perpendicular = rel - along[:, None] * shower_direction[None, :]
    distance_axis = np.linalg.norm(perpendicular, axis=1)

    original_time = array["t"].astype(np.float64)
    relative_time = original_time - np.nanmin(original_time)
    frame = pd.DataFrame({
        "shower_id": shower_id,
        "particle_row_id": np.arange(len(array), dtype=np.int64),
        "condition_id": condition_id,
        "run_id": run_id,
        "corsika_run_number": run_number,
        "corsika_event_number": event_number,
        "particle_description_original": description,
        "corsika_particle_code": codes,
        "hadronic_generation": generation,
        "observation_level_index": observation_level,
        "species": [item["species"] for item in info],
        "pdg_id": pd.array([item["pdg"] for item in info], dtype="Int64"),
        "particle_group": [item["group"] for item in info],
        "mass_GeV_c2": mass,
        "px_GeV_c": px,
        "py_GeV_c": py,
        "pz_down_GeV_c": pz,
        "momentum_GeV_c": momentum,
        "energy_total_GeV": energy,
        "energy_kinetic_GeV": kinetic,
        "direction_north": direction_north,
        "direction_west": direction_west,
        "direction_down": direction_down,
        "direction_zenith_deg": direction_zenith,
        "direction_azimuth_deg": direction_azimuth,
        "x_output_cm": x_prime,
        "y_output_cm": y_prime,
        "time_corsika_ns": original_time,
        "time_relative_first_particle_ns": relative_time,
        "x_cartesian_m": x_cart_m,
        "y_cartesian_m": y_cart_m,
        "z_cartesian_local_m": z_cart_m,
        "radial_arc_m": arc_cm / 100.0,
        "radial_chord_m": radial_chord_m,
        "distance_to_shower_axis_m": distance_axis,
        "statistical_weight": 1.0,
        "statistical_weight_source": "implicit_unthinned",
        "is_derived_energy": True,
        "is_derived_coordinate": True,
    })
    return frame[PARTICLE_COLUMNS]


def profile_frames(
    profile: dict[str, Any],
    shower_id: str,
    condition_id: str,
    run_id: str,
    run_number: int,
    event_number: int,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    common = {
        "shower_id": shower_id,
        "condition_id": condition_id,
        "run_id": run_id,
        "corsika_run_number": run_number,
        "corsika_event_number": event_number,
    }
    particles = pd.DataFrame({
        **common,
        "depth_vertical_g_cm2": profile["particles"]["depth"],
        "gammas": profile["particles"]["gammas"],
        "positrons": profile["particles"]["positrons"],
        "electrons": profile["particles"]["electrons"],
        "mu_plus": profile["particles"]["mu_plus"],
        "mu_minus": profile["particles"]["mu_minus"],
        "hadrons": profile["particles"]["hadrons"],
        "charged": profile["particles"]["charged"],
        "nuclei": profile["particles"]["nuclei"],
        "cherenkov": profile["particles"]["cherenkov"],
    })
    deposit = pd.DataFrame({
        **common,
        "depth_vertical_g_cm2": profile["energy_deposition"]["depth"],
        "gamma_cut_GeV": profile["energy_deposition"]["gamma"],
        "em_ionization_GeV": profile["energy_deposition"]["em_ioniz"],
        "em_cut_GeV": profile["energy_deposition"]["em_cut"],
        "muon_ionization_GeV": profile["energy_deposition"]["mu_ioniz"],
        "muon_cut_GeV": profile["energy_deposition"]["mu_cut"],
        "hadron_ionization_GeV": profile["energy_deposition"]["hadr_ioniz"],
        "hadron_cut_GeV": profile["energy_deposition"]["hadr_cut"],
        "neutrino_GeV": profile["energy_deposition"]["neutrino"],
        "sum_deposit_GeV": profile["energy_deposition"]["sum"],
    })
    return particles[LONG_PARTICLE_COLUMNS], deposit[LONG_DEPOSIT_COLUMNS]


def concat_or_empty(frames: Iterable[pd.DataFrame], columns: list[str]) -> pd.DataFrame:
    materialized = [frame for frame in frames if not frame.empty]
    return pd.concat(materialized, ignore_index=True) if materialized else pd.DataFrame(columns=columns)


def card_seed_sequences(path: Path) -> list[int]:
    values: list[int] = []
    for line in path.read_text(encoding="ascii").splitlines():
        fields = line.split()
        if fields and fields[0].upper() == "SEED" and len(fields) >= 2:
            values.append(int(fields[1]))
    return values


def clean_output(output_dir: Path, force: bool) -> None:
    if output_dir.exists() and any(output_dir.iterdir()):
        if not force:
            raise FileExistsError(f"El directorio de salida no esta vacio: {output_dir}; use --force")
        resolved = output_dir.resolve()
        if PROJECT_ROOT.resolve() not in resolved.parents or resolved == PROJECT_ROOT.resolve():
            raise RuntimeError(f"Ruta de limpieza fuera del proyecto: {resolved}")
        shutil.rmtree(resolved)
    output_dir.mkdir(parents=True, exist_ok=True)


def export_stage(stage: str, output_dir: Path, force: bool) -> dict[str, Any]:
    config = load_config()
    clean_output(output_dir, force)
    raw_root = PROJECT_ROOT / "data" / "raw" / stage
    result_paths = sorted(raw_root.glob("**/run.json"))
    if not result_paths:
        raise FileNotFoundError(f"No hay corridas para la etapa {stage}")
    results = [json.loads(path.read_text(encoding="utf-8")) for path in result_paths]
    result_by_condition: dict[str, list[dict[str, Any]]] = {}
    for result in results:
        result_by_condition.setdefault(result["condition_id"], []).append(result)

    conditions = pd.DataFrame(config["conditions"])
    conditions["azimuth_deg"] = float(config["physics"]["azimuth_deg"])
    conditions["atmosphere_model_id"] = int(config["physics"]["atmosphere_model_id"])
    conditions["observation_level_m_asl"] = float(config["physics"]["observation_level_m_asl"])
    conditions.to_parquet(output_dir / "conditions.parquet", index=False)

    run_rows: list[dict[str, Any]] = []
    shower_rows: list[dict[str, Any]] = []
    reader_warnings: list[str] = []
    raw_layouts: dict[str, dict[str, Any]] = {}

    particles_root = output_dir / "particles"
    long_particles_root = output_dir / "longitudinal_particles"
    long_deposit_root = output_dir / "longitudinal_energy_deposit"
    for condition in config["conditions"]:
        condition_id = condition["condition_id"]
        condition_particle_frames: list[pd.DataFrame] = []
        condition_long_particle_frames: list[pd.DataFrame] = []
        condition_long_deposit_frames: list[pd.DataFrame] = []
        for result in sorted(result_by_condition.get(condition_id, []), key=lambda item: (item["run_number"], item.get("replicate", ""))):
            row = {key: value for key, value in result.items() if key != "condition"}
            requested_seeds = card_seed_sequences(PROJECT_ROOT / result["card_path"])
            row.update({
                "primary_requested": condition["primary"],
                "primary_code_requested": condition["primary_code"],
                "energy_total_requested_GeV": condition["energy_total_GeV"],
                "zenith_requested_deg": condition["zenith_deg"],
                "azimuth_requested_deg": config["physics"]["azimuth_deg"],
                "corsika_version": config["corsika"]["version"],
                "high_energy_model": config["corsika"]["high_energy_hadronic_model"],
                "low_energy_model": config["corsika"]["low_energy_hadronic_model"],
                "electromagnetic_model": config["corsika"]["electromagnetic_model"],
                "atmosphere_model_id": config["physics"]["atmosphere_model_id"],
                "observation_level_cm_asl": config["physics"]["observation_level_cm_asl"],
                "magnetic_field_horizontal_north_uT": config["physics"]["magnetic_field_horizontal_north_uT"],
                "magnetic_field_vertical_down_uT": config["physics"]["magnetic_field_vertical_down_uT"],
                "thinning": False,
                "seed_sequence_1_requested": requested_seeds[0] if len(requested_seeds) > 0 else None,
                "seed_sequence_2_requested": requested_seeds[1] if len(requested_seeds) > 1 else None,
                "random_engine": "CORSIKA 7 interno; algoritmo no inferido de la salida",
            })
            if result["status"] != "complete":
                run_rows.append(row)
                continue
            run_dir = PROJECT_ROOT / Path(result["raw_path"]).parent
            raw_path = PROJECT_ROOT / result["raw_path"]
            long_path = PROJECT_ROOT / result["longitudinal_path"]
            layout = inspect_binary_layout(raw_path)
            raw_layouts[result["run_id"]] = layout
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                with corsikaio.CorsikaParticleFile(raw_path, thinning=False) as corsika_file:
                    run_header = corsika_file.run_header
                    events = list(corsika_file)
                    run_end = corsika_file.run_end
            reader_warnings.extend(str(item.message) for item in caught)
            profiles = list(corsikaio.read_longitudinal_distributions(long_path))
            profile_by_event = {int(profile["shower"]): profile for profile in profiles}
            row.update({
                "run_header_run_number": int(round(float(run_header["run_number"]))),
                "run_header_version": float(run_header["version"]),
                "run_header_n_showers": int(round(float(run_header["n_showers"]))),
                "run_end_n_showers": int(round(float(np.asarray(run_end["n_events"]).reshape(-1)[0]))),
                "events_read": len(events),
                "profiles_read": len(profiles),
                **{f"layout_{key}": json.dumps(value, sort_keys=True) if isinstance(value, dict) else value for key, value in layout.items()},
            })
            run_rows.append(row)

            for event in events:
                header, array, _long_blocks, end = event
                event_number = int(round(float(header["event_number"])))
                run_number = int(round(float(header["run_number"])))
                replicate_suffix = f"__rep{result['replicate']}" if result.get("replicate") else ""
                shower_id = f"{condition_id}__r{run_number:06d}__e{event_number:06d}{replicate_suffix}"
                primary_zenith_rad = float(header["zenith"])
                primary_azimuth_rad = float(header["azimuth"])
                observation_height_cm = float(header["observation_height"][0])
                particles = particle_frame(
                    array, shower_id, condition_id, result["run_id"], run_number, event_number,
                    observation_height_cm, primary_zenith_rad, primary_azimuth_rad,
                )
                condition_particle_frames.append(particles)
                counts = particles["particle_group"].value_counts().to_dict() if not particles.empty else {}
                code_counts = particles["corsika_particle_code"].value_counts().sort_index().to_dict() if not particles.empty else {}
                finite_energy = particles["energy_total_GeV"].dropna() if not particles.empty else pd.Series(dtype=float)
                first_interaction_raw = float(header["first_interaction_height"])
                shower_rows.append({
                    "shower_id": shower_id,
                    "condition_id": condition_id,
                    "run_id": result["run_id"],
                    "corsika_run_number": run_number,
                    "corsika_event_number": event_number,
                    "status": "complete",
                    "primary_code_header": int(round(float(header["particle_id"]))),
                    "primary_species_header": species_info(int(round(float(header["particle_id"]))))["species"],
                    "primary_energy_total_GeV_header": float(header["total_energy"]),
                    "primary_zenith_deg_header": math.degrees(primary_zenith_rad),
                    "primary_azimuth_deg_header": math.degrees(primary_azimuth_rad),
                    "primary_px_GeV_c_header": float(header["momentum_x"]),
                    "primary_py_GeV_c_header": float(header["momentum_y"]),
                    "primary_pz_down_GeV_c_header": float(header["momentum_minus_z"]),
                    "first_interaction_height_raw_cm": first_interaction_raw,
                    "first_interaction_height_m_asl": abs(first_interaction_raw) / 100.0,
                    "tracking_started_at_atmosphere_margin": first_interaction_raw < 0,
                    "observation_level_m_asl": observation_height_cm / 100.0,
                    "seed_sequence_1": int(round(float(header["random_seeds"][0][0]))),
                    "seed_sequence_2": int(round(float(header["random_seeds"][1][0]))),
                    "n_particle_records": len(particles),
                    "n_electromagnetic": int(counts.get("electromagnetic", 0)),
                    "n_muon": int(counts.get("muon", 0)),
                    "n_hadron": int(counts.get("hadron", 0)),
                    "n_nucleus": int(counts.get("nucleus", 0)),
                    "n_unknown": int(counts.get("unknown", 0)),
                    "particle_code_counts_json": json.dumps({str(k): int(v) for k, v in code_counts.items()}, sort_keys=True),
                    "particle_energy_total_min_GeV": float(finite_energy.min()) if len(finite_energy) else None,
                    "particle_energy_total_median_GeV": float(finite_energy.median()) if len(finite_energy) else None,
                    "particle_energy_total_max_GeV": float(finite_energy.max()) if len(finite_energy) else None,
                    "radial_arc_max_m": float(particles["radial_arc_m"].max()) if len(particles) else None,
                    "distance_to_axis_max_m": float(particles["distance_to_shower_axis_m"].max()) if len(particles) else None,
                    "time_corsika_min_ns": float(particles["time_corsika_ns"].min()) if len(particles) else None,
                    "time_corsika_max_ns": float(particles["time_corsika_ns"].max()) if len(particles) else None,
                    "time_span_ns": float(particles["time_corsika_ns"].max() - particles["time_corsika_ns"].min()) if len(particles) else None,
                    "event_end_n_particles_written": int(round(float(end["n_particles_written"]))),
                    "longitudinal_fit_chi_square": float(end["chi_square_longitudinal"]),
                    "has_ground_particles": bool(len(particles)),
                    "has_longitudinal_profile": event_number in profile_by_event,
                })
                if event_number in profile_by_event:
                    long_particles, long_deposit = profile_frames(
                        profile_by_event[event_number], shower_id, condition_id, result["run_id"], run_number, event_number
                    )
                    condition_long_particle_frames.append(long_particles)
                    condition_long_deposit_frames.append(long_deposit)

        partition = f"condition_id={condition_id}"
        particle_output = particles_root / partition
        long_particle_output = long_particles_root / partition
        long_deposit_output = long_deposit_root / partition
        particle_output.mkdir(parents=True, exist_ok=True)
        long_particle_output.mkdir(parents=True, exist_ok=True)
        long_deposit_output.mkdir(parents=True, exist_ok=True)
        concat_or_empty(condition_particle_frames, PARTICLE_COLUMNS).to_parquet(
            particle_output / "part-000.parquet", index=False
        )
        concat_or_empty(condition_long_particle_frames, LONG_PARTICLE_COLUMNS).to_parquet(
            long_particle_output / "part-000.parquet", index=False
        )
        concat_or_empty(condition_long_deposit_frames, LONG_DEPOSIT_COLUMNS).to_parquet(
            long_deposit_output / "part-000.parquet", index=False
        )

    runs = pd.DataFrame(run_rows)
    showers = pd.DataFrame(shower_rows)
    runs.to_parquet(output_dir / "runs.parquet", index=False)
    showers.to_parquet(output_dir / "showers.parquet", index=False)
    metadata = {
        "dataset_schema_version": "1.0",
        "stage": stage,
        "generated_utc": pd.Timestamp.now(tz="UTC").isoformat(),
        "corsika_version": config["corsika"]["version"],
        "reader": "corsikaio 0.5.0",
        "reader_warnings_unique": sorted(set(reader_warnings)),
        "conditions": len(conditions),
        "runs_total": len(runs),
        "runs_complete": int((runs["status"] == "complete").sum()),
        "showers_complete": len(showers),
        "particle_rows": int(showers["n_particle_records"].sum()) if len(showers) else 0,
        "profiles_particle_rows": sum(len(pd.read_parquet(path)) for path in long_particles_root.glob("**/*.parquet")),
        "profiles_energy_deposit_rows": sum(len(pd.read_parquet(path)) for path in long_deposit_root.glob("**/*.parquet")),
        "raw_layouts": raw_layouts,
        "physics": config["physics"],
        "campaign_configuration": config,
        "field_provenance": {
            "particle_output_original": [
                "particle_description_original", "px_GeV_c", "py_GeV_c", "pz_down_GeV_c",
                "x_output_cm", "y_output_cm", "time_corsika_ns"
            ],
            "particle_output_decoded": [
                "corsika_particle_code", "hadronic_generation", "observation_level_index",
                "species", "pdg_id", "particle_group", "mass_GeV_c2"
            ],
            "particle_output_derived": [
                "momentum_GeV_c", "energy_total_GeV", "energy_kinetic_GeV",
                "direction_north", "direction_west", "direction_down",
                "direction_zenith_deg", "direction_azimuth_deg",
                "time_relative_first_particle_ns", "x_cartesian_m", "y_cartesian_m",
                "z_cartesian_local_m", "radial_arc_m", "radial_chord_m",
                "distance_to_shower_axis_m", "statistical_weight"
            ]
        },
        "interpretation_limits": [
            "Cada fila de particula es un registro al nivel de observacion, no un track_id.",
            "No se registraron genealogias, procesos creadores ni trayectorias.",
            "Los tiempos pertenecen a cada cascada; no definen intervalos entre cascadas.",
            "Los perfiles usan profundidad atmosferica vertical en g/cm2, no altura geometrica.",
            "Las energias derivadas se calculan solo para conversiones de especie con masa verificada."
        ]
    }
    metadata_path = output_dir / "dataset_metadata.json"
    metadata_path.write_text(json.dumps(metadata, indent=2, ensure_ascii=False), encoding="utf-8")
    metadata["metadata_sha256"] = sha256_file(metadata_path)
    return metadata


def main() -> None:
    parser = argparse.ArgumentParser(description="Convierte salidas CORSIKA 7 a tablas independientes")
    parser.add_argument("--stage", default="production", choices=["matrix", "pilot", "production", "reproducibility"])
    parser.add_argument("--output", type=Path)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    output = args.output or (PROJECT_ROOT / ("data/full" if args.stage == "production" else f"_work/{args.stage}_tables"))
    metadata = export_stage(args.stage, output, args.force)
    summary_keys = [
        "stage",
        "runs_total",
        "runs_complete",
        "showers_complete",
        "particle_rows",
        "profiles_particle_rows",
        "profiles_energy_deposit_rows",
    ]
    print(json.dumps({key: metadata[key] for key in summary_keys}, indent=2, ensure_ascii=False))
    print(f"metadata: {output / 'dataset_metadata.json'}")


if __name__ == "__main__":
    main()

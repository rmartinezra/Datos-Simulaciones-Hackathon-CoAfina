from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from campaign_common import (
    PROJECT_ROOT,
    build_card,
    load_config,
    parse_memory_mib,
    read_wsl_memory_total_mib,
    sha256_file,
)


STAGE_BASE = {
    "matrix": 110_000,
    "pilot": 210_000,
    "production": 310_000,
    "reproducibility": 910_000,
}


@dataclass(frozen=True)
class Job:
    stage: str
    condition_index: int
    condition: dict[str, Any]
    block_index: int
    n_showers: int
    run_number: int
    first_event_number: int
    replicate: str = ""

    @property
    def block_id(self) -> str:
        suffix = f"_{self.replicate}" if self.replicate else ""
        return f"block_{self.block_index:03d}{suffix}"

    @property
    def run_id(self) -> str:
        return f"run_{self.run_number:06d}{('_' + self.replicate) if self.replicate else ''}"


def build_jobs(config: dict[str, Any], stage: str, production_events: int | None = None) -> list[Job]:
    conditions = config["conditions"]
    jobs: list[Job] = []
    if stage == "matrix":
        n_per_block, n_blocks = 1, 1
    elif stage == "pilot":
        n_per_block, n_blocks = 5, 1
    elif stage == "production":
        total = production_events or int(config["campaign"]["target_events_per_condition"])
        block_size = int(config["campaign"]["block_size"])
        if total % block_size:
            raise ValueError("production_events debe ser multiplo de block_size")
        n_per_block, n_blocks = block_size, total // block_size
    elif stage == "reproducibility":
        condition_index = 4
        condition = conditions[condition_index - 1]
        return [
            Job(stage, condition_index, condition, 0, 1, 910_401, 1, replicate="a"),
            Job(stage, condition_index, condition, 0, 1, 910_401, 1, replicate="b"),
        ]
    else:
        raise ValueError(f"Etapa no soportada: {stage}")

    base = STAGE_BASE[stage]
    for condition_index, condition in enumerate(conditions, start=1):
        for block_index in range(n_blocks):
            run_number = base + condition_index * 100 + block_index
            first_event_number = block_index * n_per_block + 1
            jobs.append(
                Job(
                    stage=stage,
                    condition_index=condition_index,
                    condition=condition,
                    block_index=block_index,
                    n_showers=n_per_block,
                    run_number=run_number,
                    first_event_number=first_event_number,
                )
            )
    return jobs


def job_directory(job: Job) -> Path:
    return PROJECT_ROOT / "data" / "raw" / job.stage / job.condition["condition_id"] / job.block_id


def result_is_complete(job: Job) -> bool:
    directory = job_directory(job)
    result_path = directory / "run.json"
    if not result_path.exists():
        return False
    try:
        result = json.loads(result_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    raw = directory / f"DAT{job.run_number:06d}"
    longitudinal = directory / f"DAT{job.run_number:06d}.long"
    return result.get("status") == "complete" and raw.is_file() and longitudinal.is_file()


def run_job(job: Job, config: dict[str, Any], resume: bool = True) -> dict[str, Any]:
    directory = job_directory(job)
    directory.mkdir(parents=True, exist_ok=True)
    if resume and result_is_complete(job):
        result = json.loads((directory / "run.json").read_text(encoding="utf-8"))
        result["resume_action"] = "skipped_existing_complete_run"
        return result

    seeds = None
    if job.stage == "reproducibility":
        seeds = (740_001, 740_002)
    card = build_card(
        config,
        job.condition,
        job.run_number,
        job.first_event_number,
        job.n_showers,
        job.stage,
        job.block_index,
        seeds=seeds,
    )
    card_path = directory / "card.inp"
    card_path.write_text(card, encoding="ascii")
    log_path = directory / f"DAT{job.run_number:06d}.lst"

    container = config["container"]
    container_name = f"ccds-{job.stage[:4]}-{job.condition_index:02d}-{job.block_index:03d}{job.replicate}"
    command = [
        "docker",
        "run",
        "--rm",
        "-i",
        "--name",
        container_name,
        "--workdir",
        container["working_directory"],
        "--entrypoint",
        container["executable"],
        "-v",
        f"{directory.resolve()}:/out",
        container["image"],
    ]

    started = datetime.now(timezone.utc)
    started_monotonic = time.monotonic()
    peak_memory_mib = 0.0
    stats_samples = 0
    with card_path.open("rb") as card_stream, log_path.open("wb") as log_stream:
        process = subprocess.Popen(command, stdin=card_stream, stdout=log_stream, stderr=subprocess.STDOUT)
        while process.poll() is None:
            stats = subprocess.run(
                ["docker", "stats", "--no-stream", "--format", "{{.MemUsage}}", container_name],
                capture_output=True,
                text=True,
                check=False,
            )
            memory_mib = parse_memory_mib(stats.stdout.strip())
            if memory_mib is not None:
                peak_memory_mib = max(peak_memory_mib, memory_mib)
                stats_samples += 1
            time.sleep(0.25)
        exit_code = int(process.returncode)
    finished = datetime.now(timezone.utc)
    # El reloj civil puede ajustarse mientras Docker/WSL esta trabajando. La
    # duracion de recursos debe provenir de un reloj monotono.
    elapsed = time.monotonic() - started_monotonic

    raw_path = directory / f"DAT{job.run_number:06d}"
    long_path = directory / f"DAT{job.run_number:06d}.long"
    log_text = log_path.read_text(encoding="utf-8", errors="replace") if log_path.exists() else ""
    complete = (
        exit_code == 0
        and raw_path.is_file()
        and raw_path.stat().st_size > 8
        and long_path.is_file()
        and long_path.stat().st_size > 0
        and "END OF RUN" in log_text
    )
    result: dict[str, Any] = {
        **asdict(job),
        "condition_id": job.condition["condition_id"],
        "run_id": job.run_id,
        "status": "complete" if complete else "failed",
        "exit_code": exit_code,
        "started_utc": started.isoformat(),
        "finished_utc": finished.isoformat(),
        "wall_seconds": elapsed,
        "peak_memory_mib": peak_memory_mib if stats_samples else None,
        "memory_samples": stats_samples,
        "card_path": str(card_path.relative_to(PROJECT_ROOT)),
        "log_path": str(log_path.relative_to(PROJECT_ROOT)),
        "raw_path": str(raw_path.relative_to(PROJECT_ROOT)) if raw_path.exists() else None,
        "longitudinal_path": str(long_path.relative_to(PROJECT_ROOT)) if long_path.exists() else None,
        "raw_bytes": raw_path.stat().st_size if raw_path.exists() else 0,
        "longitudinal_bytes": long_path.stat().st_size if long_path.exists() else 0,
        "log_bytes": log_path.stat().st_size if log_path.exists() else 0,
        "raw_sha256": sha256_file(raw_path) if raw_path.exists() else None,
        "longitudinal_sha256": sha256_file(long_path) if long_path.exists() else None,
        "card_sha256": sha256_file(card_path),
        "image": container["image"],
        "image_id": container["image_id"],
        "executable": container["executable"],
        "resume_action": "executed",
    }
    (directory / "run.json").write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    return result


def summarize_stage(stage: str, results: list[dict[str, Any]], workers: int) -> dict[str, Any]:
    manifest_dir = PROJECT_ROOT / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    complete = [r for r in results if r["status"] == "complete"]
    total_events = sum(int(r["n_showers"]) for r in complete)
    summary = {
        "stage": stage,
        "workers": workers,
        "jobs_total": len(results),
        "jobs_complete": len(complete),
        "jobs_failed": sum(r["status"] == "failed" for r in results),
        "events_complete": total_events,
        "raw_bytes": sum(int(r["raw_bytes"]) for r in complete),
        "longitudinal_bytes": sum(int(r["longitudinal_bytes"]) for r in complete),
        "log_bytes": sum(int(r["log_bytes"]) for r in complete),
        "worker_seconds": sum(float(r["wall_seconds"]) for r in complete),
        "max_peak_memory_mib": max(
            (float(r["peak_memory_mib"]) for r in complete if r.get("peak_memory_mib") is not None),
            default=None,
        ),
        "runs": results,
    }
    (manifest_dir / f"{stage}_runs.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    return summary


def production_plan(config: dict[str, Any]) -> tuple[int, int, dict[str, Any]]:
    pilot_path = PROJECT_ROOT / "manifests" / "pilot_runs.json"
    if not pilot_path.exists():
        raise RuntimeError("Debe completarse el piloto antes de planificar produccion")
    pilot = json.loads(pilot_path.read_text(encoding="utf-8"))
    runs = [run for run in pilot["runs"] if run["status"] == "complete"]
    if len(runs) != len(config["conditions"]):
        raise RuntimeError("El piloto no tiene una corrida completa por condicion")

    campaign = config["campaign"]
    target = int(campaign["target_events_per_condition"])
    block_size = int(campaign["block_size"])
    total_ram_mib = read_wsl_memory_total_mib()
    memory_budget_mib = total_ram_mib * float(campaign["memory_fraction_limit"])
    peak = max(float(run.get("peak_memory_mib") or 0.0) for run in runs)
    if peak <= 0:
        memory_workers = 1
    else:
        memory_workers = int(memory_budget_mib // (peak * 1.10))
    cpu_workers = max(1, (os.cpu_count() or 1) // 2)
    workers = min(int(campaign["max_workers"]), cpu_workers, memory_workers)
    if workers < 1:
        raise RuntimeError(
            f"Una corrida requiere {peak:.1f} MiB y excede el presupuesto de memoria de {memory_budget_mib:.1f} MiB"
        )

    seconds_per_event_by_condition = {
        run["condition_id"]: float(run["wall_seconds"]) / int(run["n_showers"]) for run in runs
    }
    bytes_per_event_by_condition = {
        run["condition_id"]: (int(run["raw_bytes"]) + int(run["longitudinal_bytes"])) / int(run["n_showers"])
        for run in runs
    }
    estimated_worker_seconds_target = sum(seconds_per_event_by_condition.values()) * target
    estimated_wall_seconds_target = estimated_worker_seconds_target / workers
    estimated_bytes_target = sum(bytes_per_event_by_condition.values()) * target

    max_time_seconds = float(campaign["max_wall_hours"]) * 3600
    max_bytes = float(campaign["max_raw_output_gib"]) * 1024**3
    time_scale = max_time_seconds / estimated_wall_seconds_target if estimated_wall_seconds_target else 1.0
    size_scale = max_bytes / estimated_bytes_target if estimated_bytes_target else 1.0
    scale = min(1.0, time_scale, size_scale)
    events = int((target * scale) // block_size) * block_size
    events = max(block_size, min(target, events))
    plan = {
        "pilot_events": pilot["events_complete"],
        "wsl_total_memory_mib": total_ram_mib,
        "memory_budget_mib": memory_budget_mib,
        "pilot_max_peak_memory_mib": peak,
        "cpu_worker_limit": cpu_workers,
        "memory_worker_limit": memory_workers,
        "selected_workers": workers,
        "target_events_per_condition": target,
        "planned_events_per_condition": events,
        "estimated_target_wall_seconds": estimated_wall_seconds_target,
        "estimated_target_output_bytes": estimated_bytes_target,
        "time_scale": time_scale,
        "size_scale": size_scale,
        "uniform_reduction_applied": events < target,
        "seconds_per_event_by_condition": seconds_per_event_by_condition,
        "bytes_per_event_by_condition": bytes_per_event_by_condition,
    }
    path = PROJECT_ROOT / "manifests" / "production_plan.json"
    path.write_text(json.dumps(plan, indent=2, ensure_ascii=False), encoding="utf-8")
    return events, workers, plan


def main() -> None:
    parser = argparse.ArgumentParser(description="Ejecuta etapas reproducibles de la campaña CORSIKA 7")
    parser.add_argument("stage", choices=["matrix", "pilot", "production", "reproducibility"])
    parser.add_argument("--workers", type=int, default=0, help="0 = automatico")
    parser.add_argument("--events-per-condition", type=int)
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument("--condition-id", help="Limita la ejecucion a una condicion (reparacion/auditoria)")
    parser.add_argument("--block-index", type=int, help="Limita la ejecucion a un bloque (reparacion/auditoria)")
    args = parser.parse_args()

    if shutil.which("docker") is None:
        raise SystemExit("No se encontro docker en PATH")
    config = load_config()
    if args.stage == "production" and args.events_per_condition is None:
        events, auto_workers, plan = production_plan(config)
        workers = args.workers or auto_workers
        print(json.dumps(plan, indent=2, ensure_ascii=False))
    else:
        events = args.events_per_condition
        workers = args.workers or min(2, max(1, (os.cpu_count() or 1) // 2))
    workers = min(workers, int(config["campaign"]["max_workers"]), max(1, (os.cpu_count() or 1) // 2))
    jobs = build_jobs(config, args.stage, production_events=events)
    if args.condition_id is not None:
        jobs = [job for job in jobs if job.condition["condition_id"] == args.condition_id]
    if args.block_index is not None:
        jobs = [job for job in jobs if job.block_index == args.block_index]
    if not jobs:
        raise SystemExit("Los filtros no seleccionaron ningun trabajo")
    results: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {executor.submit(run_job, job, config, not args.no_resume): job for job in jobs}
        for future in as_completed(futures):
            job = futures[future]
            try:
                result = future.result()
            except Exception as exc:
                result = {
                    **asdict(job),
                    "condition_id": job.condition["condition_id"],
                    "run_id": job.run_id,
                    "status": "failed",
                    "error": repr(exc),
                    "raw_bytes": 0,
                    "longitudinal_bytes": 0,
                    "log_bytes": 0,
                    "wall_seconds": 0.0,
                    "peak_memory_mib": None,
                }
            results.append(result)
            print(
                f"{result['status']:8s} {job.condition['condition_id']} {job.block_id} "
                f"{result.get('wall_seconds', 0):.1f}s {result.get('peak_memory_mib')} MiB",
                flush=True,
            )
    results.sort(key=lambda item: (item["condition_index"], item["block_index"], item.get("replicate", "")))
    summary = summarize_stage(args.stage, results, workers)
    print(json.dumps({key: value for key, value in summary.items() if key != "runs"}, indent=2))
    if summary["jobs_failed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()

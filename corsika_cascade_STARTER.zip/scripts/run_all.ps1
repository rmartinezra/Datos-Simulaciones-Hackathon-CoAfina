$ErrorActionPreference = "Stop"
$projectWindows = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path
$projectWsl = (wsl wslpath -a $projectWindows).Trim()
if (-not $projectWsl) {
    throw "No se pudo convertir la ruta del proyecto para WSL."
}
wsl bash -lc "cd '$projectWsl' && bash scripts/run_all.sh"
if ($LASTEXITCODE -ne 0) {
    throw "La reproduccion termino con codigo $LASTEXITCODE."
}

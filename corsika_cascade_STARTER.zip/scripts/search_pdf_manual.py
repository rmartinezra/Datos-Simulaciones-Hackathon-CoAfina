"""Auxiliar empleado para localizar convenciones en el manual PDF local de CORSIKA."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from pypdf import PdfReader


DEFAULT_TERMS = [
    "PHIP", "MAGNET", "OBSLEV", "ECUTS", "LONGI", "particle data",
    "arrival time", "time delay", "coordinate system", "PRMPAR", "ERANGE",
    "ATMOD", "RUNH", "EVTH", "genealogy", "trajectory", "generation",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf", type=Path, help="Manual PDF local; no se redistribuye con el proyecto")
    parser.add_argument("--pages", help="Paginas PDF (base 1) separadas por comas")
    parser.add_argument("--terms", nargs="*", default=DEFAULT_TERMS)
    args = parser.parse_args()
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    reader = PdfReader(str(args.pdf))
    if args.pages:
        for raw in args.pages.split(","):
            number = int(raw)
            print(f"\n===== PDF PAGE {number} =====\n")
            print(reader.pages[number - 1].extract_text() or "")
        return
    texts = [(page.extract_text() or "").casefold() for page in reader.pages]
    print(f"pages {len(reader.pages)}")
    for term in args.terms:
        matches = [index for index, text in enumerate(texts, start=1) if term.casefold() in text]
        print(term, matches)


if __name__ == "__main__":
    main()

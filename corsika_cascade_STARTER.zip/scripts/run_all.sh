#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$project_dir"

if [[ ! -x .venv/bin/python ]]; then
  python3 -m venv --system-site-packages .venv
fi
.venv/bin/python -m pip install -r requirements.txt

.venv/bin/python scripts/run_campaign.py matrix
.venv/bin/python scripts/extract_dataset.py --stage matrix --force
.venv/bin/python scripts/validate_dataset.py --stage matrix

.venv/bin/python scripts/run_campaign.py pilot
.venv/bin/python scripts/extract_dataset.py --stage pilot --force
.venv/bin/python scripts/validate_dataset.py --stage pilot

.venv/bin/python scripts/run_campaign.py reproducibility
.venv/bin/python scripts/check_reproducibility.py
.venv/bin/python scripts/extract_dataset.py --stage reproducibility --force
.venv/bin/python scripts/validate_dataset.py --stage reproducibility
.venv/bin/python scripts/run_campaign.py production
.venv/bin/python scripts/repair_clock_metrics.py
.venv/bin/python scripts/extract_dataset.py --stage production --force
.venv/bin/python scripts/validate_dataset.py --stage production
.venv/bin/python scripts/crosscheck_official_reader.py
.venv/bin/python scripts/summarize_dataset.py
.venv/bin/python scripts/make_visualizations.py
.venv/bin/python scripts/package_dataset.py

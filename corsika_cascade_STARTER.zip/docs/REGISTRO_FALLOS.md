# Registro de fallos e incidencias

## Incidencia de orquestación antes de la matriz válida

En el primer intento de la matriz, el contenedor Docker se inició sin `-i`. El ejecutable no recibió la tarjeta por entrada estándar, comenzó con valores por defecto y cuatro trabajos terminaron como fallidos antes de que se detuvieran y retiraran dos contenedores temporales restantes. No se reutilizó ninguno de esos resultados. Se corrigió el comando, se sobrescribieron únicamente esos directorios diagnósticos y se repitió la matriz completa; los 12 trabajos válidos posteriores están en el manifiesto.

Esta incidencia no representa cascadas fallidas de la campaña física y sus archivos inválidos no forman parte de STARTER, FULL ni `data/raw` vigente.

## Salto del reloj civil

Durante dos bloques tempranos de producción, el reloj de Windows cambió aproximadamente dos horas. Esto sólo afectó el cálculo inicial de `wall_seconds`; no cambió semillas, tarjetas ni contenidos. Se sustituyó la medición por `time.monotonic()`, se repitieron exactamente los bloques afectados y se regeneró el manifiesto a partir de los `run.json` corregidos. Los hashes se usan para comprobar identidad física.

El primer intento de reparar el primer bloque conservó el archivo binario en su directorio. CORSIKA terminó con código 1 y el mensaje `FILE ... ALREADY EXISTS`, sin sobrescribir el binario ni el perfil. Se ajustó el procedimiento para mover cada directorio anterior a una copia recuperable dentro de `_work/clock_metric_backups`, ejecutar en un directorio limpio y aceptar el resultado sólo si tarjeta, binario y perfil coincidían por SHA-256. Los dos bloques pasaron esa comparación. Esta fue una incidencia de reparación de metadatos, no un fallo de la campaña física.

## Política de fallos de simulación

Un trabajo se considera completo sólo si:

- Docker devuelve código 0;
- existen el binario y el archivo `.long` no vacíos;
- el log contiene `END OF RUN`;
- el lector valida la estructura y encuentra los eventos esperados.

Los eventos completos con cero partículas al nivel de observación **no son fallos**. Se preservan con `has_ground_particles=false` y con su perfil longitudinal.

Los manifiestos distinguen trabajos completos y fallidos. No se reemplaza silenciosamente un evento fallido con otro de distinta semilla.

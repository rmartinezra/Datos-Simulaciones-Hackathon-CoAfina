# Diccionario de datos y unidades

## Organización

FULL usa Parquet. `particles`, `longitudinal_particles` y `longitudinal_energy_deposit` están particionadas físicamente por `condition_id`; esa columna también se conserva dentro de cada archivo. STARTER contiene las mismas variables en CSV comprimidos con gzip.

`condition_id`, `run_id` y `shower_id` son identificadores creados por este proyecto. Los números originales de corrida/evento también se conservan.

## `conditions`

| Campo | Unidad/tipo | Significado |
|---|---|---|
| `condition_id` | texto | Identificador único de la condición. |
| `primary` | texto | `gamma` o `proton`. |
| `primary_code` | entero CORSIKA | 1 para fotón, 14 para protón. |
| `energy_total_GeV` | GeV | Energía total primaria solicitada; incluye masa en reposo. |
| `zenith_deg` | grados | Ángulo cenital solicitado. |
| `azimuth_deg` | grados | Azimut solicitado según convención CORSIKA. |
| `atmosphere_model_id` | entero | Identificador `ATMOD`. |
| `observation_level_m_asl` | m s. n. m. | Altura del nivel de observación. |

## `runs`

| Campo(s) | Unidad/tipo | Significado |
|---|---|---|
| `stage` | texto | `matrix`, `pilot`, `production` o `reproducibility`. |
| `condition_index`, `block_index` | entero | Posición de condición y bloque en la planificación. |
| `n_showers` | entero | Eventos solicitados al trabajo. |
| `run_number`, `first_event_number` | entero CORSIKA | Número de corrida y primer número de evento. |
| `replicate` | texto | Sufijo usado sólo en la prueba repetida. |
| `condition_id`, `run_id` | texto | Claves del proyecto. |
| `status`, `exit_code` | texto, entero | Estado del trabajo y código de Docker/CORSIKA. |
| `started_utc`, `finished_utc` | ISO-8601 UTC | Marcas civiles de inicio/fin. |
| `wall_seconds` | s | Duración medida con reloj monotónico. |
| `peak_memory_mib`, `memory_samples` | MiB, entero | Pico observado con `docker stats` y número de muestras. |
| `card_path`, `log_path`, `raw_path`, `longitudinal_path` | ruta relativa | Archivos que permiten auditar/reproducir el trabajo. |
| `raw_bytes`, `longitudinal_bytes`, `log_bytes` | bytes | Tamaños. |
| `raw_sha256`, `longitudinal_sha256`, `card_sha256` | hexadecimal | Hashes de integridad. |
| `image`, `image_id`, `executable` | texto | Infraestructura exacta utilizada. |
| `resume_action` | texto | Ejecutado o reconocido como ya completo. |
| `primary_requested`, `primary_code_requested` | texto, entero | Primaria solicitada. |
| `energy_total_requested_GeV` | GeV | Energía total solicitada. |
| `zenith_requested_deg`, `azimuth_requested_deg` | grados | Dirección solicitada. |
| `corsika_version` | texto | Versión del simulador. |
| `high_energy_model`, `low_energy_model`, `electromagnetic_model` | texto | Modelos físicos. |
| `atmosphere_model_id` | entero | Modelo atmosférico. |
| `observation_level_cm_asl` | cm s. n. m. | Nivel configurado en la tarjeta. |
| `magnetic_field_horizontal_north_uT`, `magnetic_field_vertical_down_uT` | µT | Componentes de `MAGNET`. |
| `thinning` | booleano | Siempre falso en esta campaña. |
| `seed_sequence_1_requested`, `seed_sequence_2_requested` | entero | Primer entero de cada línea `SEED` de la tarjeta. |
| `random_engine` | texto | Motor registrado sólo hasta el grado verificable; no se adivina el algoritmo cuando la salida no lo identifica. |
| `run_header_run_number`, `run_header_version`, `run_header_n_showers` | cabecera RUNH | Valores extraídos del binario. |
| `run_end_n_showers` | entero RUNE | Número de eventos declarado al final. |
| `events_read`, `profiles_read` | entero | Conteos obtenidos por el lector. |
| `layout_byte_order` | texto | Endianness detectado. |
| `layout_fortran_record_marker_bytes` | bytes | Tamaño del marcador de registro. |
| `layout_record_payload_bytes` | bytes | Carga útil de cada registro Fortran. |
| `layout_subblock_float_words`, `layout_particle_float_words` | entero | Palabras por subbloque/partícula. |
| `layout_thinning_format` | booleano | Variante inferida del tamaño de registro. |
| `layout_records` | entero | Registros Fortran completos. |
| `layout_tags` | JSON | Conteo de etiquetas RUNH/EVTH/LONG/EVTE/RUNE. |
| `layout_file_bytes` | bytes | Tamaño verificado del binario. |

## `showers`

| Campo | Unidad/tipo | Significado |
|---|---|---|
| `shower_id` | texto | Identificador único global. |
| `condition_id`, `run_id` | texto | Claves foráneas. |
| `corsika_run_number`, `corsika_event_number` | entero | Identificadores originales. |
| `status` | texto | Estado de la cascada extraída. |
| `primary_code_header`, `primary_species_header` | entero, texto | Primaria real en EVTH. |
| `primary_energy_total_GeV_header` | GeV | Energía total real en EVTH. |
| `primary_zenith_deg_header`, `primary_azimuth_deg_header` | grados | Dirección real en EVTH. |
| `primary_px_GeV_c_header`, `primary_py_GeV_c_header`, `primary_pz_down_GeV_c_header` | GeV/c | Momento primario; ejes norte/oeste/abajo. |
| `first_interaction_height_raw_cm` | cm | EVTH(7) sin alterar. Su magnitud es la altura de primera interacción; el signo negativo señala inicio de seguimiento en el margen atmosférico. |
| `first_interaction_height_m_asl` | m s. n. m. | Magnitud de EVTH(7) convertida a metros; no es la altura del margen atmosférico. |
| `tracking_started_at_atmosphere_margin` | booleano | Interpretación documentada del signo negativo. |
| `observation_level_m_asl` | m s. n. m. | Nivel real en EVTH. |
| `seed_sequence_1`, `seed_sequence_2` | entero | Primer valor de las dos secuencias aleatorias iniciales declarado en EVTH; se repite dentro de una corrida y está cuantizado por el almacenamiento `float32`. Los enteros exactos están en `runs` y en la tarjeta. |
| `n_particle_records` | entero | Filas registradas al nivel de observación. |
| `n_electromagnetic`, `n_muon`, `n_hadron`, `n_nucleus`, `n_unknown` | entero | Conteos por grupo. |
| `particle_code_counts_json` | JSON | Conteo por código CORSIKA original decodificado. |
| `particle_energy_total_min_GeV`, `particle_energy_total_median_GeV`, `particle_energy_total_max_GeV` | GeV | Resúmenes derivados de filas con masa verificada. |
| `radial_arc_max_m` | m | Máximo radio de arco en la salida curva. |
| `distance_to_axis_max_m` | m | Máxima distancia perpendicular derivada al eje. |
| `time_corsika_min_ns`, `time_corsika_max_ns`, `time_span_ns` | ns | Resúmenes del tiempo original. |
| `event_end_n_particles_written` | entero EVTE | Registros escritos declarados por CORSIKA. |
| `longitudinal_fit_chi_square` | adimensional | Valor del ajuste longitudinal exportado en EVTE. |
| `has_ground_particles` | booleano | Distingue cascadas completas sin filas de partículas. |
| `has_longitudinal_profile` | booleano | Existe perfil asociado. |

## `particles`

| Campo | Unidad/tipo | Origen/significado |
|---|---|---|
| `shower_id`, `condition_id`, `run_id` | texto | Claves del proyecto. |
| `particle_row_id` | entero | Fila única 0…N−1 dentro de la cascada; **no es un identificador físico de track**. |
| `corsika_run_number`, `corsika_event_number` | entero | Identificadores originales. |
| `particle_description_original` | entero | Palabra original redondeada: `código×1000 + generación×10 + nivel`. |
| `corsika_particle_code` | entero | Código decodificado según la tabla del manual 7.8010. |
| `hadronic_generation` | entero | Generación empaquetada por CORSIKA; no es genealogía. |
| `observation_level_index` | entero | Índice de nivel; 1 en esta campaña. |
| `species`, `pdg_id`, `particle_group` | texto/entero nullable | Conversión explícita cuando está verificada. |
| `mass_GeV_c2` | GeV/c² nullable | Masa usada para energía, contrastada con `parmas` de `/opt/corsika/src/utils/corsikaread.cpp`; nula si la especie no está verificada. |
| `px_GeV_c`, `py_GeV_c`, `pz_down_GeV_c` | GeV/c | Componentes originales: norte, oeste y abajo. |
| `momentum_GeV_c` | GeV/c | Norma derivada del momento. |
| `energy_total_GeV` | GeV nullable | `sqrt(p²+m²)` sólo con masa verificada. |
| `energy_kinetic_GeV` | GeV nullable | Energía total menos masa. |
| `direction_north`, `direction_west`, `direction_down` | adimensional | Componentes unitarias derivadas. |
| `direction_zenith_deg`, `direction_azimuth_deg` | grados | Dirección local derivada; azimut mediante `atan2(oeste,norte)`. |
| `x_output_cm`, `y_output_cm` | cm | Coordenadas primas originales de `CURVOUT`. |
| `time_corsika_ns` | ns | Tiempo original desde la entrada atmosférica en esta ejecución, sin convertirlo en el retraso respecto de frente esférico del formato `.tab` opcional. |
| `time_relative_first_particle_ns` | ns | `t − min(t)` dentro de la cascada. |
| `x_cartesian_m`, `y_cartesian_m`, `z_cartesian_local_m` | m | Punto derivado en el sistema cartesiano local; `z` es la coordenada respecto del punto de nivel del mar bajo el núcleo, no una nueva altura radial. Toda la superficie está a 110 m de altura radial. |
| `radial_arc_m`, `radial_chord_m` | m | Distancia angular superficial y cuerda horizontal derivadas. |
| `distance_to_shower_axis_m` | m | Distancia perpendicular local al eje primario, no trayectoria. |
| `statistical_weight` | adimensional | 1,0 implícito por ausencia de thinning. |
| `statistical_weight_source` | texto | `implicit_unthinned`. |
| `is_derived_energy`, `is_derived_coordinate` | booleano | Marcas de procedencia. |

Conversión de la superficie curva, con `R = 637.131.500 cm`, altura `h`, `r = sqrt(x'²+y'²)`, `θ=r/(R+h)` y `φ=atan2(y',x')`:

```text
d = (R+h) sin θ
x = d cos φ
y = d sin φ
z = (R+h) cos θ - R
```

No se proyecta una línea hasta la cima de la atmósfera. `distance_to_shower_axis_m` es una distancia geométrica al eje ideal, no evidencia de una trayectoria registrada.

## `longitudinal_particles`

| Campo | Unidad/tipo | Significado |
|---|---|---|
| Identificadores | texto/entero | `shower_id`, `condition_id`, `run_id`, corrida y evento. |
| `depth_vertical_g_cm2` | g/cm² | Profundidad atmosférica vertical. |
| `gammas`, `positrons`, `electrons`, `mu_plus`, `mu_minus`, `hadrons`, `charged`, `nuclei`, `cherenkov` | población exportada | Valores que CORSIKA escribió en el perfil. `cherenkov` permanece sin producción porque esa opción estaba desactivada. |

## `longitudinal_energy_deposit`

| Campo | Unidad/tipo | Significado |
|---|---|---|
| Identificadores | texto/entero | `shower_id`, `condition_id`, `run_id`, corrida y evento. |
| `depth_vertical_g_cm2` | g/cm² | Profundidad atmosférica vertical. |
| `gamma_cut_GeV` | GeV | Energía de fotones bajo corte exportada. |
| `em_ionization_GeV`, `em_cut_GeV` | GeV | Ionización y términos de corte electromagnéticos. |
| `muon_ionization_GeV`, `muon_cut_GeV` | GeV | Términos de muones. |
| `hadron_ionization_GeV`, `hadron_cut_GeV` | GeV | Términos hadrónicos. |
| `neutrino_GeV` | GeV | Término de neutrinos exportado. |
| `sum_deposit_GeV` | GeV | Suma reportada por CORSIKA. |

Los perfiles son agregados por profundidad. No contienen partículas individuales ni reconstruyen su historia.

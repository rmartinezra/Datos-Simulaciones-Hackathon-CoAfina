# Inventario y configuración física

## Entorno utilizado

La campaña se ejecutó en Windows 11 Home Single Language 10.0.26300 (compilación 26300), con WSL2 Ubuntu, Docker 29.7.2 y Python 3.12.3. El equipo tiene un Intel Core i5-12450H, 8 núcleos físicos, 12 procesadores lógicos y 15,65 GiB de RAM. WSL tenía asignados 7,58 GiB de RAM y 2 GiB de intercambio; la planificación limitó el uso a la mitad de la RAM de WSL y a la mitad de los procesadores lógicos. Al comenzar había aproximadamente 288 GiB libres en la unidad de Windows y 879 GiB en el sistema de archivos de WSL.

No se encontró un `AGENTS.md` en el espacio de trabajo. Tampoco se encontró una instalación de CORSIKA 8: todos los archivos, identificadores y comandos de este proyecto corresponden exclusivamente a CORSIKA 7.

## Instalación reutilizada

Se reutilizó como infraestructura la imagen Docker local `rmartinezmaple/arti_lidera:latest`, sin ejecutar la cadena de ponderación o muestreo de flujo de ARTI.

- ID de imagen: `sha256:77cb342d23bb1a6100e60582a265bab3040d41c43ffaff3e63fadd7db7747fa8`.
- Digest registrado: `sha256:4aee12a437e57f31dd546f8d6df88cf70c58a24b1623cc30e905eb458a53593a`.
- CORSIKA: 7.8010, fecha declarada por el ejecutable 2025-04-03.
- Ejecutable usado: `/opt/corsika/run/corsika78010Linux_QGSIII_fluka`.
- ARTI presente: v1r9, revisión Git `6741b79407d415a571012c77585d830d0eea361d` (2022-11-13).

Ejecutables alternativos hallados, pero no empleados: variantes con SIBYLL, EPOS y DPMJET, además de compilaciones con thinning. La campaña no mezcla resultados de esos ejecutables.

## Capacidades verificadas

El banner y los logs de la ejecución seleccionada confirman:

| Componente | Configuración |
|---|---|
| Modelo hadrónico de alta energía | QGSJET-III-01 |
| Modelo hadrónico de baja energía | FLUKA 2025.0.0 |
| Cascada electromagnética | EGS4 |
| Transición alta/baja energía | 80 GeV |
| Opciones compiladas relevantes | `UNIX`, `TIMERC`, `VOLUMEDET`, `ATMEXT`, `CURVED`, `EFIELD`, `LPM` |
| Thinning | Desactivado; formato de 7 palabras por partícula |
| Cherenkov | Desactivado |
| Radio/CoREAS | Desactivado |
| Historial/genealogía | `EHISTORY`, `MUADDI` y `EMADDI` desactivados |
| Perfil longitudinal | `LONGI`, paso vertical de 10 g/cm², ajuste y archivo externo activados |
| NKG | No disponible en esta combinación con `CURVED`; EGS4 sí está activo |

Los archivos binarios producidos tienen registros Fortran con marcadores de 4 bytes, carga útil de 22.932 bytes, 21 subbloques de 273 `float32` y siete palabras por registro de partícula. El lector comprueba explícitamente endianness, marcadores inicial/final, tamaño, etiquetas y ausencia de thinning.

Una opción compilada no implica que se haya usado en la tarjeta. No se definió ningún campo eléctrico atmosférico pese a que `EFIELD` está disponible; tampoco se configuró un detector volumétrico. `ATMEXT` está disponible, pero la campaña eligió `ATMOD 1`. El log sí declara activo el efecto LPM.

## Configuración física común

Esta es una **configuración de referencia** reproducible, basada en tarjetas compatibles disponibles dentro de la instalación local. No se atribuye a Bucaramanga ni a ningún sitio real porque atmósfera, campo y altura no fueron verificados conjuntamente para un emplazamiento.

| Parámetro | Valor |
|---|---:|
| Atmósfera | `ATMOD 1`, atmósfera estándar de EE. UU. parametrizada por Linsley |
| Nivel de observación | 11.000 cm = 110 m s. n. m. |
| Superficie | Curva (`CURVED`/`CURVOUT`) |
| Campo horizontal hacia norte | 20,0 µT |
| Campo vertical hacia abajo | 42,8 µT |
| Rotación del arreglo | 0° |
| Azimut | 0° fijo |
| Umbral cinético de hadrones | 0,3 GeV |
| Umbral cinético de muones | 0,3 GeV |
| Umbral cinético de electrones/positrones | 0,003 GeV |
| Umbral de energía de fotones | 0,003 GeV |

`ECUTS` no significa que se almacenen todas las partículas creadas: sólo se siguen y registran las que satisfacen los cortes y condiciones de transporte/salida.

## Matriz controlada

Se conservaron las doce condiciones inicialmente propuestas, sin ajuste posterior al piloto:

- primarias: fotón (`PRMPAR 1`) y protón (`PRMPAR 14`);
- energías totales: 100 GeV, 1 TeV y 10 TeV (`ERANGE` con límites iguales);
- cenit: 0° y 30°;
- azimut: 0°.

En CORSIKA 7, `ERANGE` expresa energía total, incluida la masa en reposo. El piloto mostró que la mayoría de los fotones de 100 GeV no deja partículas registradas a 110 m, pero todos conservan perfil longitudinal. Es físicamente plausible que una cascada electromagnética de esa energía se haya atenuado al atravesar hasta una profundidad cercana al nivel del mar, especialmente a 30°, y que su cola caiga bajo los cortes de 3 MeV. Las cabeceras, cierres y perfiles completos descartan un truncamiento de archivo. Se mantuvieron los eventos vacíos y no se cambió la altura para hacerlos visualmente más llamativos.

Esta matriz permite comparar cascadas bajo condiciones controladas. No representa la abundancia relativa de fotones y protones ni un flujo cósmico realista.

## Convenciones de ejes, dirección y tiempo

- Eje `+x`: norte magnético; eje `+y`: oeste; eje `+z`: hacia arriba.
- En la salida de partículas, `px` apunta al norte, `py` al oeste y `pz` es positivo hacia abajo.
- Azimut 0°: el eje de la cascada apunta al norte magnético; 90° apunta al oeste.
- `x_output_cm` e `y_output_cm` son las coordenadas primas de `CURVOUT` sobre la superficie curva. Se conservan sin alterar.
- Las coordenadas cartesianas añadidas usan el radio terrestre de CORSIKA, 6.371.315 m, y se identifican como derivadas.
- `time_corsika_ns` se conserva. En esta compilación curva el seguimiento comienza en el margen de la atmósfera, comprobado por el log y por el valor negativo de EVTH(7); ésa es la referencia temporal pertinente.
- `time_relative_first_particle_ns = time_corsika_ns - min(time_corsika_ns)` dentro de cada cascada. No se construye una cronología entre cascadas independientes.

El manual distingue este `t` del binario —tiempo desde primera interacción o entrada atmosférica— de la distribución opcional del archivo `.tab`, que expresa retraso respecto de un frente esférico. La salida `.tab` no se activó y aquí no se aplicó ninguna corrección de frente. El único cambio temporal es la columna relativa, siempre conservando `time_corsika_ns`.

La profundidad de los perfiles es profundidad atmosférica **vertical** en g/cm². No es altura geométrica y no se ha convertido a ella.

## ARTI y datos previos

ARTI sirvió únicamente para proporcionar una imagen local con CORSIKA funcional y documentación/lectores de referencia. Se inspeccionó su lector `analysis.cc`, pero no se usó su cadena `.shw`: esta campaña necesita conservar el evento individual, el tiempo original y la configuración sin aplicar selección de flujo. No se aplicaron espectros, pesos, filtros de detectores ni muestreos temporales propios de campañas de flujo.

Se inspeccionó el archivo previo `/home/rafael/proyectos/CABRIALES/data/bga-2212-01_043200/bga-2212-01_043200.shw`. Es una salida ARTI curva con 55.774.047 partículas seleccionadas y 10.907.401 showers, pero no contiene por sí sola la procedencia completa requerida para esta matriz controlada. No se modificó ni se incorporó al dataset.

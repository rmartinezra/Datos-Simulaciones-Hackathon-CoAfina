# Licencias y publicación

## Resultado de la auditoría local

| Componente | Evidencia local | Licencia declarada |
|---|---|---|
| ARTI v1r9 | `/opt/arti/LICENSE` | BSD de 3 cláusulas; copyright LAGO Collaboration |
| Árbol CORSIKA 7.8010 | `/opt/corsika/COPYING` | Texto GNU GPL versión 2 |
| `corsikaio 0.5.0` | metadatos instalados | MIT |
| NumPy 1.26.4 | metadatos instalados | BSD de 3 cláusulas |
| pandas 2.1.4 | metadatos instalados | BSD de 3 cláusulas |
| PyArrow 17.0.0 | metadatos instalados | Apache 2.0 |
| Matplotlib 3.6.3 | metadatos instalados | PSF |
| pypdf 5.9.0 | `License-Expression` instalado | BSD de 3 cláusulas |

El ejecutable CORSIKA enlaza o usa modelos externos, incluidos QGSJET-III y FLUKA. La presencia de `COPYING` en el árbol principal no demuestra por sí sola que todos esos componentes puedan redistribuirse bajo los mismos términos. Por cautela, los paquetes STARTER y FULL **no incluyen** la imagen Docker, ejecutables ni fuentes de CORSIKA/FLUKA/QGSJET. Sólo incluyen datos generados, código original de preparación, metadatos, documentación y rutas/hashes de procedencia.

Antes de publicación pública, los titulares deben revisar las condiciones de CORSIKA y de cada modelo utilizado, además de las reglas institucionales sobre datos simulados.

## Propuestas pendientes de adopción

- Código original del proyecto: BSD de 3 cláusulas, borrador en `LICENSE_CODE_PROPOSAL.txt`.
- Dataset generado: Creative Commons Attribution 4.0 International (CC BY 4.0), propuesta en `LICENSE_DATA_PROPOSAL.txt`.

Son propuestas y no concesiones vigentes. Hasta que los titulares sustituyan los marcadores y adopten expresamente una licencia, se mantienen los derechos por defecto. No se creó DOI, enlace público ni publicación externa.

# Validación y límites de interpretación

## Validaciones implementadas

`scripts/validate_dataset.py` comprueba, sin imponer supuestos físicos falsos:

- correspondencia entre especie, energía total, cenit y azimut solicitados y las cabeceras EVTH;
- número de corrida y eventos en RUNH/RUNE frente a la tarjeta de entrada;
- estructura de registros Fortran, endianness, marcadores, subbloques y variante sin thinning;
- identificadores de corrida/cascada únicos y claves foráneas de partículas/perfiles;
- unicidad y secuencia de `particle_row_id` dentro de cada cascada;
- conteos por cascada, grupo y EVTE consistentes;
- valores originales finitos;
- peso implícito unitario coherente con ausencia de thinning;
- conversión documentada de códigos, dejando nulas las conversiones desconocidas;
- relación relativista `E² = p² + m²` en unidades GeV para masas verificadas;
- norma unitaria de direcciones derivadas;
- tiempo relativo igual a cero en el primer registro temporal de cada cascada;
- perfiles asociados a la cascada correcta y profundidad creciente;
- pares de semillas iniciales distintos entre trabajos independientes y constantes dentro de una corrida;
- hashes SHA-256 de binarios y perfiles originales.

No se exige que los registros estén ordenados por tiempo. Tampoco se exige conservación de energía sumando sólo partículas al nivel de observación: faltan depósitos atmosféricos, partículas bajo umbral y otros términos.

## Lectores contrastados

La extracción usa `corsikaio 0.5.0`. Antes de interpretar los datos, el script también inspecciona directamente los marcadores y tamaños binarios. `scripts/crosscheck_official_reader.py` selecciona una corrida no vacía mediante una regla determinista, ejecuta `/opt/corsika/src/utils/corsikaread` incluido con CORSIKA y compara su `NTOT` con el número de filas leído por `corsikaio`.

`corsikaio 0.5.0` no enumera 7.8010 como etiqueta específica y avisa que usa las definiciones generales de cabecera/fin de evento de CORSIKA 7.x (y la definición EVTH 7.7xxx). Los avisos se conservan en `dataset_metadata.json`. No se silenciaron conceptualmente: se mitigaron contrastando tamaños y marcadores con la variante compilada, RUNH/RUNE/EVTH/EVTE con tarjetas y conteos, perfiles con sus eventos, y `NTOT` con el lector oficial de la misma instalación.

Los informes ejecutados están en `reports/validation_matrix.*`, `reports/validation_pilot.*`, `reports/validation_reproducibility.*`, `reports/validation_production.*`, `reports/reproducibility.json`, `reports/official_reader_crosscheck.json` y `reports/clock_metric_repair.json`.

## Reproducibilidad

Se ejecutó dos veces la misma condición (fotón, 1 TeV, 30°), con la misma tarjeta y los mismos pares de semillas. Los archivos binarios de partículas y los perfiles longitudinales de ambas repeticiones tienen SHA-256 idénticos. Las semillas que EVTH repite en los eventos son las semillas iniciales de la corrida; el estado del generador avanza internamente entre eventos. Como EVTH es `float32`, semillas enteras grandes pueden aparecer redondeadas unos pocos enteros: la validación compara con esa representación y conserva el entero exacto de la tarjeta en `runs`.

## Campos presentes

- Propiedades primarias reales de EVTH.
- Partículas registradas en el único nivel de observación: código original empaquetado, momento, coordenadas de salida y tiempo.
- Código, generación hadrónica y nivel de observación decodificados según el manual local de CORSIKA 7.8010.
- Especie, PDG y masa sólo para conversiones incluidas explícitamente en el lector.
- Energías total/cinética y direcciones derivadas.
- Coordenadas cartesianas de la superficie curva, radio y distancia perpendicular al eje, siempre marcadas como derivadas.
- Perfiles longitudinales de poblaciones y depósito energético realmente exportados por `LONGI`.

## Campos ausentes

Esta salida no contiene genealogía de partículas, padres físicos, procesos creadores, puntos de interacción ni trayectorias completas. `particle_row_id` es sólo un identificador único de fila dentro del evento; no es `track_id`.

Las partículas que llegan al nivel de observación no permiten reconstruir automáticamente cómo se relacionaron dentro de la cascada. Los perfiles longitudinales agregados tampoco restauran esa historia.

No hay cronología física entre eventos. El número de evento sólo organiza simulaciones independientes. No se produjeron fotones Cherenkov, radio, trazas de detectores ni mediciones experimentales.

## Precauciones estadísticas

- Cada fila representa un registro real de la salida sin thinning y tiene peso implícito 1.
- Las figuras de fluctuación resumen primero por cascada; no tratan cada partícula como réplica independiente para estimar dispersión entre showers.
- Los eventos con cero partículas al nivel de observación permanecen en `showers` y en los perfiles.
- Las figuras que reducen puntos por legibilidad declaran la regla exacta en `figures/figure_metadata.json`; el dataset no se reduce.
- La matriz tiene igual número de eventos por condición deliberadamente y no debe interpretarse como una composición de rayos cósmicos.

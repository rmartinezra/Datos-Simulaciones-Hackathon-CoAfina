# Validacion de pilot

Estado: **PASS**

| Comprobacion | Estado | Detalle |
|---|---:|---|
| `archivos_tabulares` | PASS | 4/4 archivos principales |
| `etapa_metadatos` | PASS | metadata.stage='pilot', esperado='pilot' |
| `matriz_condiciones` | PASS | 12/12 condiciones |
| `corridas_completas` | PASS | completas=12, total=12 |
| `ids_corrida_unicos` | PASS | unicos=12, filas=12 |
| `ids_cascada_unicos` | PASS | unicos=60, filas=60 |
| `cascadas_por_condicion_uniformes` | PASS | esperado=5; {"gamma_E0100GeV_Z00_A000": 5, "gamma_E0100GeV_Z30_A000": 5, "gamma_E10000GeV_Z00_A000": 5, "gamma_E10000GeV_Z30_A000": 5, "gamma_E1000GeV_Z00_A000": 5, "gamma_E1000GeV_Z30_A000": 5, "proton_E0100GeV_Z00_A000": 5, "proton_E0100GeV_Z30_A000": 5, "proton_E10000GeV_Z00_A000": 5, "proton_E10000GeV_Z30_A000": 5, "proton_E1000GeV_Z00_A000": 5, "proton_E1000GeV_Z30_A000": 5} |
| `conteo_metadatos` | PASS | cascadas=60, particulas=25651 |
| `entrada_vs_cabecera_primaria` | PASS | especie, energia total, cenit y azimut |
| `momento_primario` | PASS | componentes norte/oeste/abajo reproducen direccion y energia total |
| `nivel_observacion` | PASS | esperado=110.0 m s.n.m. |
| `cabeceras_cascada_finitas` | PASS | campos fisicos obligatorios de EVTH/EVTE |
| `altura_primera_interaccion` | PASS | magnitud de EVTH(7), por encima del nivel de observacion; signo conservado como bandera |
| `cabeceras_corrida` | PASS | RUNH/RUNE/eventos/perfiles coinciden con la tarjeta |
| `version_cabecera` | PASS | RUNH declara CORSIKA 7.8010 |
| `formato_binario` | PASS | registros sin thinning de 7 palabras; marcadores Fortran verificados |
| `bloques_binarios` | PASS | RUNH/RUNE unicos y un par EVTH/EVTE por evento |
| `fk_particulas` | PASS | filas=25651 |
| `fk_perfiles` | PASS | poblaciones=6180, depositos=6180 |
| `ids_fila_particula` | PASS | unicos y consecutivos dentro de cada cascada; no son track_id |
| `conteos_por_cascada` | PASS | total_tabla=25651, total_resumen=25651 |
| `conteos_por_grupo` | PASS | grupos suman los registros de cada cascada |
| `conteo_evte` | PASS | EVTE coincide con filas leidas |
| `resumenes_vacios_y_no_vacios` | PASS | resumenes finitos si hay registros y nulos si no los hay |
| `valores_originales_finitos` | PASS | px_GeV_c, py_GeV_c, pz_down_GeV_c, x_output_cm, y_output_cm, time_corsika_ns |
| `peso_sin_thinning` | PASS | peso implicito=1 |
| `indice_nivel_observacion` | PASS | unico nivel, indice CORSIKA 1 |
| `relacion_energia_momento` | PASS | conversiones con masa verificada=25651 |
| `codigos_particula_reconocidos` | PASS | desconocidos=0; se mantienen nulos, nunca inferidos |
| `coordenadas_derivadas` | PASS | arco, cuerda, superficie esferica y distancia al eje coherentes |
| `direcciones_unitarias` | PASS | componentes derivadas de momento |
| `tiempo_relativo` | PASS | se conserva time_corsika_ns y la columna derivada inicia en cero |
| `perfil_por_cascada` | PASS | con ambos perfiles=60, cascadas=60 |
| `profundidad_longitudinal` | PASS | profundidad vertical finita, creciente y sin duplicados por cascada |
| `valores_perfiles` | PASS | poblaciones y depositos finitos y no negativos |
| `semillas_por_corrida` | PASS | pares exactos distintos entre trabajos=12/12; EVTH repite las semillas iniciales dentro de la corrida |
| `semillas_tarjeta_vs_evth` | PASS | EVTH coincide con la representacion float32 de las semillas enteras exactas de la tarjeta |
| `integridad_sha256_fuentes` | PASS | archivos comprobados=24 |

## Metricas

```json
{
  "conditions": 12,
  "runs": 12,
  "showers": 60,
  "showers_without_ground_particles": 10,
  "particle_rows": 25651,
  "longitudinal_particle_rows": 6180,
  "longitudinal_deposit_rows": 6180,
  "unknown_particle_rows": 0
}
```

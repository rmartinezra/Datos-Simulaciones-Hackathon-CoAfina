# Validacion de production

Estado: **PASS**

| Comprobacion | Estado | Detalle |
|---|---:|---|
| `archivos_tabulares` | PASS | 4/4 archivos principales |
| `etapa_metadatos` | PASS | metadata.stage='production', esperado='production' |
| `matriz_condiciones` | PASS | 12/12 condiciones |
| `corridas_completas` | PASS | completas=120, total=120 |
| `ids_corrida_unicos` | PASS | unicos=120, filas=120 |
| `ids_cascada_unicos` | PASS | unicos=1200, filas=1200 |
| `cascadas_por_condicion_uniformes` | PASS | esperado=100; {"gamma_E0100GeV_Z00_A000": 100, "gamma_E0100GeV_Z30_A000": 100, "gamma_E10000GeV_Z00_A000": 100, "gamma_E10000GeV_Z30_A000": 100, "gamma_E1000GeV_Z00_A000": 100, "gamma_E1000GeV_Z30_A000": 100, "proton_E0100GeV_Z00_A000": 100, "proton_E0100GeV_Z30_A000": 100, "proton_E10000GeV_Z00_A000": 100, "proton_E10000GeV_Z30_A000": 100, "proton_E1000GeV_Z00_A000": 100, "proton_E1000GeV_Z30_A000": 100} |
| `conteo_metadatos` | PASS | cascadas=1200, particulas=505126 |
| `entrada_vs_cabecera_primaria` | PASS | especie, energia total, cenit y azimut |
| `momento_primario` | PASS | componentes norte/oeste/abajo reproducen direccion y energia total |
| `nivel_observacion` | PASS | esperado=110.0 m s.n.m. |
| `cabeceras_cascada_finitas` | PASS | campos fisicos obligatorios de EVTH/EVTE |
| `altura_primera_interaccion` | PASS | magnitud de EVTH(7), por encima del nivel de observacion; signo conservado como bandera |
| `cabeceras_corrida` | PASS | RUNH/RUNE/eventos/perfiles coinciden con la tarjeta |
| `version_cabecera` | PASS | RUNH declara CORSIKA 7.8010 |
| `formato_binario` | PASS | registros sin thinning de 7 palabras; marcadores Fortran verificados |
| `bloques_binarios` | PASS | RUNH/RUNE unicos y un par EVTH/EVTE por evento |
| `fk_particulas` | PASS | filas=505126 |
| `fk_perfiles` | PASS | poblaciones=123600, depositos=123600 |
| `ids_fila_particula` | PASS | unicos y consecutivos dentro de cada cascada; no son track_id |
| `conteos_por_cascada` | PASS | total_tabla=505126, total_resumen=505126 |
| `conteos_por_grupo` | PASS | grupos suman los registros de cada cascada |
| `conteo_evte` | PASS | EVTE coincide con filas leidas |
| `resumenes_vacios_y_no_vacios` | PASS | resumenes finitos si hay registros y nulos si no los hay |
| `valores_originales_finitos` | PASS | px_GeV_c, py_GeV_c, pz_down_GeV_c, x_output_cm, y_output_cm, time_corsika_ns |
| `peso_sin_thinning` | PASS | peso implicito=1 |
| `indice_nivel_observacion` | PASS | unico nivel, indice CORSIKA 1 |
| `relacion_energia_momento` | PASS | conversiones con masa verificada=505126 |
| `codigos_particula_reconocidos` | PASS | desconocidos=0; se mantienen nulos, nunca inferidos |
| `coordenadas_derivadas` | PASS | arco, cuerda, superficie esferica y distancia al eje coherentes |
| `direcciones_unitarias` | PASS | componentes derivadas de momento |
| `tiempo_relativo` | PASS | se conserva time_corsika_ns y la columna derivada inicia en cero |
| `perfil_por_cascada` | PASS | con ambos perfiles=1200, cascadas=1200 |
| `profundidad_longitudinal` | PASS | profundidad vertical finita, creciente y sin duplicados por cascada |
| `valores_perfiles` | PASS | poblaciones y depositos finitos y no negativos |
| `semillas_por_corrida` | PASS | pares exactos distintos entre trabajos=120/120; EVTH repite las semillas iniciales dentro de la corrida |
| `semillas_tarjeta_vs_evth` | PASS | EVTH coincide con la representacion float32 de las semillas enteras exactas de la tarjeta |
| `integridad_sha256_fuentes` | PASS | archivos comprobados=240 |

## Metricas

```json
{
  "conditions": 12,
  "runs": 120,
  "showers": 1200,
  "showers_without_ground_particles": 198,
  "particle_rows": 505126,
  "longitudinal_particle_rows": 123600,
  "longitudinal_deposit_rows": 123600,
  "unknown_particle_rows": 0
}
```

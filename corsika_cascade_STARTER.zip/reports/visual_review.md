# Revisión visual de las figuras finales

Fecha: 22 de octubre de 2026.

Se inspeccionaron a resolución completa las nueve figuras PNG generadas desde `data/full`:

- `01_multiplicidad_por_condicion.png`;
- `02_composicion_secundarios.png`;
- `03_huellas_contrastantes.png`;
- `04_distribucion_radial.png`;
- `04b_distribucion_radial_registros.png`;
- `05_energia_secundarios.png`;
- `05b_distribucion_energia_registros.png`;
- `06_tiempo_vs_distancia.png`;
- `07_perfiles_longitudinales.png`.

Resultado: **PASS**. No se observaron títulos, ejes, leyendas o paneles recortados; las escalas logarítmicas/simétricas son legibles; los eventos de multiplicidad cero se representan en las comparaciones correspondientes; y la leyenda de huellas no oculta los datos. Los criterios deterministas de selección, normalización y submuestreo están documentados en `figures/figure_metadata.json`.


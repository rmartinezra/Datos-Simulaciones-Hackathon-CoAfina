# Informe final de la campaña CORSIKA

Fecha de cierre local: 22 de octubre de 2026.

## Resultado

La campaña produjo **1.200 cascadas completas**, 100 por cada una de las 12 condiciones previstas. No hubo cascadas incompletas ni fallidas. Se conservaron 198 eventos completos sin partículas registradas al nivel de observación; todos tienen su cabecera y perfil longitudinal y no fueron reemplazados ni descartados.

La representación independiente contiene:

- 505.126 registros de partículas al nivel de observación;
- 468.374 registros electromagnéticos, 35.178 de muones y 1.574 hadrónicos;
- 123.600 filas de poblaciones longitudinales;
- 123.600 filas de depósito longitudinal de energía;
- cero códigos de partícula sin conversión verificada en las salidas obtenidas.

Son simulaciones de cascadas atmosféricas, no mediciones. El muestreo uniforme de condiciones no representa un flujo o una composición realista de rayos cósmicos.

## Instalación empleada

- CORSIKA 7.8010; no se encontró ni se mezcló CORSIKA 8.
- Ejecutable: `/opt/corsika/run/corsika78010Linux_QGSIII_fluka`.
- QGSJET-III-01 a alta energía, FLUKA 2025.0.0 a baja energía y EGS4 para la cascada electromagnética.
- Imagen local: `rmartinezmaple/arti_lidera:latest`, digest registrado en `config/campaign.json`.
- ARTI v1r9 se reutilizó sólo como infraestructura. No se aplicaron sus ponderaciones, selecciones ni muestreo de flujo.
- Host Windows 11 con WSL2 Ubuntu, Intel Core i5-12450H, 8 núcleos físicos/12 lógicos y 15,65 GiB de RAM; WSL dispuso de 7.764,8 MiB.

## Configuración física

Se usó una sola configuración de referencia, no atribuida a Bucaramanga ni a otro sitio real:

- atmósfera `ATMOD 1`, estándar de EE. UU. parametrizada por Linsley;
- nivel de observación a 110 m s. n. m. y superficie curva;
- campo magnético de 20,0 µT hacia el norte y 42,8 µT hacia abajo;
- azimut fijo 0°: eje de la cascada hacia el norte magnético; 90° hacia el oeste;
- transición hadrónica a 80 GeV;
- cortes `ECUTS`: hadrones 0,3 GeV cinéticos, muones 0,3 GeV cinéticos, electrones/positrones 0,003 GeV cinéticos y fotones 0,003 GeV;
- perfiles `LONGI` cada 10 g/cm² de profundidad vertical;
- sin thinning, Cherenkov, radio, `EHISTORY`, `MUADDI`, `EMADDI` ni `SLANT`.

El dataset contiene las partículas que cumplieron las condiciones de seguimiento y registro; no todas las partículas creadas en la cascada.

## Matriz propuesta y ejecutada

La matriz inicial se mantuvo sin ajustes: fotón y protón; energía total de 100 GeV, 1 TeV y 10 TeV; cenit 0° y 30°; azimut 0°. Se ejecutaron 100 eventos en cada condición.

| Condición | Cascadas | Sin partículas al nivel | Registros de partículas |
|---|---:|---:|---:|
| fotón, 100 GeV, 0° | 100 | 80 | 47 |
| fotón, 100 GeV, 30° | 100 | 95 | 7 |
| fotón, 1 TeV, 0° | 100 | 1 | 2.681 |
| fotón, 1 TeV, 30° | 100 | 13 | 403 |
| fotón, 10 TeV, 0° | 100 | 0 | 115.311 |
| fotón, 10 TeV, 30° | 100 | 0 | 19.193 |
| protón, 100 GeV, 0° | 100 | 3 | 884 |
| protón, 100 GeV, 30° | 100 | 6 | 620 |
| protón, 1 TeV, 0° | 100 | 0 | 10.898 |
| protón, 1 TeV, 30° | 100 | 0 | 6.050 |
| protón, 10 TeV, 0° | 100 | 0 | 250.642 |
| protón, 10 TeV, 30° | 100 | 0 | 98.390 |
| **Total** | **1.200** | **198** | **505.126** |

El piloto justificó conservar la matriz. La ausencia frecuente de partículas al nivel de observación en fotones de 100 GeV es compatible con cascadas atenuadas cerca del nivel del mar: los eventos cierran correctamente y conservan perfiles longitudinales. No se cambió la altura para obtener resultados más vistosos.

## Etapas y validación

Se ejecutaron, en orden:

1. una prueba mínima de un evento;
2. un evento por cada una de las 12 condiciones;
3. un piloto de cinco eventos por condición, 60 en total;
4. dos repeticiones de control con tarjeta y semillas idénticas;
5. 120 trabajos de producción, diez eventos por bloque, con dos trabajadores;
6. extracción, validación, contraste con lector oficial, resúmenes, figuras y empaquetado.

Producción pasó 38 de 38 comprobaciones, sin advertencias ni fallos. La matriz y el piloto también pasaron 38 de 38. La prueba de reproducibilidad pasó 36 de 36 y produjo hashes SHA-256 idénticos en el binario de partículas y el perfil longitudinal. En la corrida de contraste, `corsikaio` y el lector oficial `corsikaread` contaron exactamente 515 registros.

Se verificaron marcadores Fortran, endianness, tamaño de registros, etiquetas, variante sin thinning, cabeceras, semillas, claves, conteos, valores finitos, pesos, unidades, energía-momento, coordenadas, tiempos relativos, perfiles y hashes. No se exigió conservar energía sumando sólo partículas al suelo.

## Tiempo, memoria y almacenamiento

- Suma de duraciones monótonas de los 120 bloques: 5.805,70 s (96,76 min de trabajo de contenedor).
- Equivalente ideal con los dos trabajadores seleccionados: 2.902,85 s (48,38 min), dentro del límite de seis horas.
- Presupuesto de memoria: 3.882,40 MiB, la mitad de la RAM de WSL.
- Pico del piloto usado para planificar: 1.372,16 MiB por contenedor; por ello se eligieron dos trabajadores.
- Pico individual máximo registrado: 2.113,54 MiB durante la repetición secuencial de una métrica de reloj, por debajo del presupuesto.
- Binarios de partículas: 19.086.080 bytes; perfiles originales: 29.824.800 bytes; logs: 24.569.411 bytes.
- Árbol bruto completo de producción, incluidas tarjetas y metadatos: 73.730.633 bytes (70,31 MiB).
- Representación FULL en Parquet antes del empaquetado: 100.107.566 bytes (95,47 MiB).
- Archivo STARTER comprimido: aproximadamente 4,00 MB; archivo FULL comprimido: aproximadamente 91,58 MB. Los bytes y SHA-256 definitivos se registran en `manifests/package_summary.json`.

Dos bloques recibieron marcas de duración anómalas por un salto del reloj civil de Windows. Se cambió la medición a reloj monótono y se repitieron esos bloques con las mismas tarjetas y semillas. Los binarios y perfiles regenerados tuvieron hashes idénticos. El primer intento de esa reparación fue rechazado por CORSIKA porque el archivo destino ya existía; no alteró los binarios y se repitió en un directorio limpio. La trazabilidad está en `reports/clock_metric_repair.json` y `docs/REGISTRO_FALLOS.md`.

## Campos presentes y ausentes

Están presentes las propiedades primarias extraídas de cabecera; partículas al nivel de observación con código original, momento, coordenadas y tiempo; especie/PDG/masa cuando la conversión está verificada; energías y direcciones derivadas; coordenadas cartesianas y distancia al eje derivadas; y perfiles longitudinales de poblaciones y depósito.

No están presentes genealogías, identificadores físicos de track, padres, procesos creadores, puntos de interacción ni trayectorias atmosféricas. `particle_row_id` sólo numera filas dentro de un evento. Los tiempos originales se conservan y el tiempo relativo sólo resta el primer registro de la misma cascada; no existe cronología entre cascadas independientes. La profundidad en g/cm² no se transformó en altura geométrica.

## Entregables locales

- STARTER: `data/starter` y `packages/corsika_cascade_STARTER.zip`.
- FULL: `data/full` y `packages/corsika_cascade_FULL.zip`.
- Salidas CORSIKA originales: `data/raw/production`.
- Figuras: `figures`.
- Código: `scripts` y `examples`.
- Configuración: `config/campaign.json`.
- Validaciones: `reports`.
- Manifiestos con filas, tamaños y SHA-256: `manifests`.

STARTER selecciona las primeras dos cascadas completas por identificador de cada condición, sin considerar su apariencia o multiplicidad. FULL contiene todas las cascadas completas. Las nueve figuras se revisaron visualmente y sus criterios de normalización o submuestreo aparecen en `figures/figure_metadata.json`.

## Publicación pendiente

No se publicó ni subió ningún archivo. Antes de hacerlo deben adoptarse formalmente las licencias propuestas, revisar las condiciones de redistribución de CORSIKA y sus modelos, decidir el repositorio, generar los metadatos editoriales y, si corresponde, solicitar un DOI. Los ZIP no incluyen ejecutables, fuentes ni la imagen Docker de CORSIKA/FLUKA/QGSJET.


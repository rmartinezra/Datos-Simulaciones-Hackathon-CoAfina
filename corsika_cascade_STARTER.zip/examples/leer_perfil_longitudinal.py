"""Lee y representa el perfil longitudinal de una cascada."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("shower_id")
    parser.add_argument("--dataset", type=Path, default=Path("data/full"))
    parser.add_argument("--output", type=Path, default=Path("perfil_longitudinal.png"))
    args = parser.parse_args()
    condition = args.shower_id.split("__r", 1)[0]
    parquet = args.dataset / "longitudinal_particles" / f"condition_id={condition}" / "part-000.parquet"
    if parquet.exists():
        profiles = pd.read_parquet(parquet)
    else:
        profiles = pd.read_csv(args.dataset / "longitudinal_particles.csv.gz")
    profile = profiles.loc[profiles["shower_id"].eq(args.shower_id)]
    if profile.empty:
        raise SystemExit("No se encontro el perfil solicitado")
    columns = ["gammas", "electrons", "positrons", "mu_plus", "mu_minus", "hadrons"]
    ax = profile.plot(x="depth_vertical_g_cm2", y=columns, logy=True, figsize=(9, 5.5))
    ax.set(xlabel="Profundidad atmosferica vertical [g/cm2]", ylabel="Poblacion exportada",
           title=args.shower_id)
    ax.grid(alpha=0.2)
    ax.figure.tight_layout()
    ax.figure.savefig(args.output, dpi=160, facecolor="white")
    print(f"Figura: {args.output.resolve()}")


if __name__ == "__main__":
    main()

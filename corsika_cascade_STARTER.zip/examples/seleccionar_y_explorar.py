"""Selecciona una cascada completa, separa especies y dibuja huella/energia/tiempo."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def read_particles(root: Path, condition_id: str) -> pd.DataFrame:
    parquet = root / "particles" / f"condition_id={condition_id}" / "part-000.parquet"
    if parquet.exists():
        return pd.read_parquet(parquet)
    csv = root / "particles.csv.gz"
    if csv.exists():
        return pd.read_csv(csv)
    raise FileNotFoundError("No se encontro particles Parquet ni particles.csv.gz")


def read_showers(root: Path) -> pd.DataFrame:
    parquet = root / "showers.parquet"
    return pd.read_parquet(parquet) if parquet.exists() else pd.read_csv(root / "showers.csv.gz")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", type=Path, default=Path("data/full"))
    parser.add_argument("--shower-id", help="Por defecto usa el primer shower_id ordenado")
    parser.add_argument("--output", type=Path, default=Path("figura_cascada.png"))
    args = parser.parse_args()

    showers = read_showers(args.dataset).sort_values("shower_id")
    shower_id = args.shower_id or showers.iloc[0]["shower_id"]
    row = showers.loc[showers["shower_id"].eq(shower_id)]
    if row.empty:
        raise SystemExit(f"shower_id desconocido: {shower_id}")
    condition_id = row.iloc[0]["condition_id"]
    particles = read_particles(args.dataset, condition_id)
    particles = particles.loc[particles["shower_id"].eq(shower_id)].copy()

    print(row.to_string(index=False))
    if particles.empty:
        print("La cascada es completa pero no tiene particulas registradas al nivel de observacion.")
        return
    print("\nConteos por especie:\n", particles["species"].value_counts().to_string())

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.8), constrained_layout=True)
    for group, frame in particles.groupby("particle_group"):
        axes[0].scatter(frame["x_cartesian_m"], frame["y_cartesian_m"], s=7, alpha=0.5, label=group)
    axes[0].set(xlabel="Norte [m]", ylabel="Oeste [m]", title="Huella")
    axes[0].set_aspect("equal", adjustable="box")
    axes[0].legend()
    axes[1].hist(particles["energy_total_GeV"].dropna(), bins=50)
    axes[1].set_xscale("log")
    axes[1].set(xlabel="Energia total [GeV]", ylabel="Registros", title="Energia")
    axes[2].scatter(particles["distance_to_shower_axis_m"], particles["time_relative_first_particle_ns"], s=6, alpha=0.35)
    axes[2].set_xscale("symlog", linthresh=1)
    axes[2].set_yscale("symlog", linthresh=1)
    axes[2].set(xlabel="Distancia al eje [m]", ylabel="Tiempo relativo [ns]", title="Tiempo vs. distancia")
    fig.suptitle(shower_id)
    fig.savefig(args.output, dpi=160, facecolor="white")
    print(f"Figura: {args.output.resolve()}")


if __name__ == "__main__":
    main()

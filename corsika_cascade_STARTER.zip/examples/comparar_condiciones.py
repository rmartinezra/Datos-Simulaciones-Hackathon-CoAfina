"""Compara multiplicidad por cascada y composicion de dos condiciones."""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def read_table(root: Path, name: str) -> pd.DataFrame:
    parquet = root / f"{name}.parquet"
    if parquet.exists():
        return pd.read_parquet(parquet)
    return pd.read_csv(root / f"{name}.csv.gz")


def particles_for(root: Path, condition_id: str) -> pd.DataFrame:
    parquet = root / "particles" / f"condition_id={condition_id}" / "part-000.parquet"
    if parquet.exists():
        return pd.read_parquet(parquet)
    frame = pd.read_csv(root / "particles.csv.gz")
    return frame.loc[frame["condition_id"].eq(condition_id)]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("condition_a")
    parser.add_argument("condition_b")
    parser.add_argument("--dataset", type=Path, default=Path("data/full"))
    parser.add_argument("--output", type=Path, default=Path("comparacion_condiciones.png"))
    args = parser.parse_args()
    showers = read_table(args.dataset, "showers")
    conditions = [args.condition_a, args.condition_b]
    selected = showers.loc[showers["condition_id"].isin(conditions)]
    if set(selected["condition_id"]) != set(conditions):
        raise SystemExit("Una o ambas condiciones no existen")
    particle_frames = [particles_for(args.dataset, condition) for condition in conditions]

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.8), constrained_layout=True)
    axes[0].boxplot([selected.loc[selected["condition_id"].eq(c), "n_particle_records"] for c in conditions], labels=conditions)
    axes[0].set_yscale("symlog", linthresh=1)
    axes[0].set(ylabel="Registros por cascada", title="Fluctuacion de multiplicidad")
    composition = pd.concat(particle_frames).groupby(["condition_id", "particle_group"]).size().unstack(fill_value=0)
    fraction = composition.div(composition.sum(axis=1).replace(0, float("nan")), axis=0).fillna(0)
    fraction.reindex(conditions).plot.bar(stacked=True, ax=axes[1])
    axes[1].set(ylabel="Fraccion de registros", title="Composicion secundaria")
    axes[1].legend(title="Grupo")
    for ax in axes:
        ax.tick_params(axis="x", labelrotation=25)
        ax.grid(axis="y", alpha=0.2)
    fig.savefig(args.output, dpi=160, facecolor="white")
    print(f"Figura: {args.output.resolve()}")


if __name__ == "__main__":
    main()

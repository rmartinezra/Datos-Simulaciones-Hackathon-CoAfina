# Dataset de cascadas CORSIKA 7 para hackathon

Este proyecto contiene una campaña controlada de **cascadas atmosféricas simuladas**, preparada para sonificación, creación audiovisual y divulgación científica. No contiene mediciones experimentales, no modela por sí solo un flujo realista de rayos cósmicos y no prescribe correspondencias musicales.

Se simulan fotones y protones a 100 GeV, 1 TeV y 10 TeV, con cenit 0°/30° y azimut 0°: doce condiciones con igual número de cascadas. La producción usa CORSIKA 7.8010, QGSJET-III-01, FLUKA 2025.0.0 y EGS4, sin thinning, Cherenkov ni radio.

La producción final contiene **1.200 cascadas completas**, **505.126 registros de partículas** y perfiles longitudinales para todos los eventos. Se conservaron 198 cascadas completas sin partículas registradas al nivel de observación. No hubo eventos incompletos ni fallidos. El cierre detallado está en [INFORME_FINAL.md](INFORME_FINAL.md).

## Entregas

- `data/starter`: pequeño subconjunto determinista, CSV comprimidos y metadatos JSON.
- `data/full`: todas las cascadas de producción en Parquet particionado, con metadatos.
- `data/raw/production`: tarjetas, logs, binarios CORSIKA y perfiles originales conservados.
- `packages/corsika_cascade_STARTER.zip` y `packages/corsika_cascade_FULL.zip`: paquetes transportables.
- `figures`: visualizaciones derivadas y criterios de selección/submuestreo.
- `reports`: validaciones legibles y JSON auditable.
- `manifests`: planificación, corridas, hashes, tamaños y filas.

Una cascada completa puede tener cero partículas al nivel de observación y aun así incluir un perfil longitudinal válido. Esos eventos no se descartan.

## Lectura rápida

Desde WSL/Ubuntu, en la raíz del proyecto:

```bash
.venv/bin/python examples/seleccionar_y_explorar.py \
  --dataset data/full \
  --shower-id gamma_E1000GeV_Z00_A000__r310300__e000001 \
  --output exploracion.png
```

Listar cascadas sin cargar la tabla grande de partículas:

```python
import pandas as pd

showers = pd.read_parquet("data/full/showers.parquet")
print(showers[["shower_id", "condition_id", "n_particle_records"]])
```

Cargar únicamente una condición:

```python
import pandas as pd

condition_id = "proton_E10000GeV_Z30_A000"
particles = pd.read_parquet(
    f"data/full/particles/condition_id={condition_id}/part-000.parquet"
)
one = particles[particles["shower_id"] == particles["shower_id"].iloc[0]]
print(one.groupby("species").size())
```

Otros ejemplos:

```bash
.venv/bin/python examples/comparar_condiciones.py \
  gamma_E1000GeV_Z00_A000 proton_E1000GeV_Z00_A000

.venv/bin/python examples/leer_perfil_longitudinal.py \
  gamma_E1000GeV_Z00_A000__r310300__e000001
```

## Reproducir toda la campaña

Requisitos: WSL2, Docker y la imagen local exacta declarada en `config/campaign.json`. No se usa Geant4.

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_all.ps1
```

O directamente desde WSL:

```bash
bash scripts/run_all.sh
```

Los comandos son reanudables: los bloques completos se reconocen por su `run.json`. La extracción y los paquetes se regeneran a partir de las salidas conservadas.

La auditoría del manual PDF usó `pypdf` sólo durante la exploración. El manual no se redistribuye. Para repetir búsquedas sobre una copia autorizada:

```bash
.venv/bin/python -m pip install -r requirements-exploration.txt
.venv/bin/python scripts/search_pdf_manual.py /ruta/al/CORSIKA_GUIDE7.8010.pdf --terms PHIP CURVOUT TSTART
```

Secuencia manual:

```bash
.venv/bin/python scripts/run_campaign.py matrix
.venv/bin/python scripts/run_campaign.py pilot
.venv/bin/python scripts/run_campaign.py reproducibility
.venv/bin/python scripts/check_reproducibility.py
.venv/bin/python scripts/extract_dataset.py --stage reproducibility --force
.venv/bin/python scripts/validate_dataset.py --stage reproducibility
.venv/bin/python scripts/run_campaign.py production
.venv/bin/python scripts/repair_clock_metrics.py
.venv/bin/python scripts/extract_dataset.py --stage production --force
.venv/bin/python scripts/validate_dataset.py --stage production
.venv/bin/python scripts/crosscheck_official_reader.py
.venv/bin/python scripts/summarize_dataset.py
.venv/bin/python scripts/make_visualizations.py
.venv/bin/python scripts/package_dataset.py
```

## Qué significan los datos

- `particle_row_id` identifica una fila, no un track físico.
- No existen genealogías, padres, procesos creadores ni trayectorias en esta salida.
- `time_corsika_ns` es el valor original; `time_relative_first_particle_ns` sólo resta el mínimo dentro de la misma cascada.
- No existen intervalos temporales físicos entre cascadas distintas.
- Las coordenadas originales y las transformadas derivadas aparecen separadas.
- La energía derivada sólo se calcula si la conversión de especie y masa está verificada.
- La profundidad longitudinal está en g/cm² verticales, no en metros.

Consulte [el inventario y configuración](docs/INVENTARIO_Y_CONFIGURACION.md), [el diccionario completo](docs/DICCIONARIO_DE_DATOS.md), [las validaciones y limitaciones](docs/VALIDACION_Y_LIMITACIONES.md), [el registro de fallos](docs/REGISTRO_FALLOS.md) y [las licencias](docs/LICENCIAS.md).
